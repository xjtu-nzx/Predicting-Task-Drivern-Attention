import os.path
import cv2
import json
import pickle
import numpy as np
from data.dataset_base import DatasetBase


class CustomDataset(DatasetBase):
    def __init__(self, opt, is_for_train):
        super(CustomDataset, self).__init__(opt, is_for_train)
        self.opt = opt
        self._is_for_train = is_for_train
        self.mode = 'train' if self._is_for_train else 'test'

        self._root_path = self._opt.data_root + 'CAD120/'
        self.attention_ann_path = self._root_path + 'attention_annotation'
        self.skeleton_ann_path = self._root_path + 'skeleton_openpose_json'
        self.raw_image_path = self._root_path + 'raw_image_224'
        # self.objects_path = self._root_path + 'objects_annotation'
        # self.RCNN_objects_path = self._root_path + 'mask_rcnn_objects'
        self.flow_path = self._root_path + 'flow'

        self.task_embed_path = self._root_path + 'CAD_task_embedding.pickle'
        with open(self.task_embed_path, 'rb') as embed_file:
            self.task_embeds = pickle.load(embed_file)

        self.action_embed_path = self._root_path + 'CAD_action_embedding.pickle'
        with open(self.action_embed_path, 'rb') as embed_file:
            self.action_embeds = pickle.load(embed_file)

        self.action_path = self._root_path + 'action_annotation/'
        self.train_list_action_path = self.action_path + \
                                      'train_list_action_dict.json'
        self.test_list_action_path = self.action_path + \
                                     'test_list_action_dict.json'

        self.H = 480
        self.W = 640
        self.input = 224
        self.gray_degree = 255
        self.temporal_num = self._opt.temporal_state
        self.train_skip_num = 5

        self.skeleton_joint = [(1, 2), (1, 5), (2, 3), (3, 4), (5, 6),
                               (6, 7), (1, 8), (8, 9), (9, 10), (1, 11),
                               (11, 12), (12, 13), (1, 0), (0, 14), (14, 16),
                               (0, 15), (15, 17)]

        self.task_index_dict = {'microwaving_food': 3,
                                'arranging_objects': 0,
                                'taking_medicine': 7,
                                'taking_food': 6,
                                'picking_objects': 4,
                                'unstacking_objects': 8,
                                'stacking_objects': 5,
                                'cleaning_objects': 1,
                                'making_cereal': 2}  # 9
        self.action_index_dict = {'pouring': 8,
                                  'cleaning': 0,
                                  'closing': 1,
                                  'opening': 6,
                                  'moving': 4,
                                  'reaching': 9,
                                  'placing': 7,
                                  'drinking': 2,
                                  'null': 5,
                                  'eating': 3}  # 10

        # action parse
        with open(self.train_list_action_path, 'r') as f:
            self.train_list_action_dict = json.load(f)
        with open(self.test_list_action_path, 'r') as f:
            self.test_list_action_dict = json.load(f)
        self.action_dict = dict(self.train_list_action_dict,
                                **self.test_list_action_dict)

        self.class_names_selected = [
            'backpack', 'umbrella', 'handbag', 'tie',
            'suitcase', 'frisbee', 'sports ball', 'bottle',
            'wine glass', 'cup', 'fork', 'knife',
            'spoon', 'bowl', 'banana', 'apple',
            'sandwich', 'orange', 'broccoli', 'carrot',
            'hot dog', 'pizza', 'donut', 'cake',
            'chair', 'potted plant', 'tv', 'laptop',
            'mouse', 'remote', 'keyboard', 'cell phone',
            'microwave', 'oven', 'toaster', 'sink',
            'refrigerator', 'book', 'clock', 'vase',
            'scissors', 'teddy bear', 'hair drier', 'toothbrush']  # 44

        self.skeleton_mask = np.zeros((self.input, self.input))
        # self.objects_mask = np.zeros((self.input, self.input))
        self.tem_one_data = np.zeros(
            (self.opt.in_channels, self.input, self.input))
        self.attention_mask = np.zeros((self.input, self.input))

        self.keys = []
        self._prepare_keys()

    def __getitem__(self, index):
        assert (index < self._dataset_size)
        key = self.keys[index]
        data_dict = self._prepare_data_by_key(key)
        sample = data_dict

        return sample

    def __len__(self):
        return self._dataset_size

    def _prepare_keys(self):
        temporal_step = self.train_skip_num if self._is_for_train \
            else self.temporal_num

        file_list_path = os.path.join(self._root_path, f'{self.mode}_list.txt')
        with open(file_list_path, 'r') as file:
            lines = file.readlines()
            total_frame = len(lines)
            past_idx = -1
            for idx, line in enumerate(lines):
                if idx + self.temporal_num < total_frame:
                    start_line = line.strip()
                    [video_name_start, frame_index_start] = start_line.rsplit(
                        '-', 1)
                    end_line = lines[idx + self.temporal_num].strip()
                    [video_name_end, frame_index_end] = end_line.rsplit('-', 1)
                    real_length = int(frame_index_end) - int(frame_index_start)
                    if video_name_start == video_name_end and idx > past_idx \
                            and real_length == self.temporal_num:
                        tem_key = '{}-{}-{}'.format(video_name_start,
                                                    frame_index_start,
                                                    frame_index_end)
                        self.keys.append(tem_key)
                        past_idx = idx + temporal_step

        # train and test length
        self._dataset_size = len(self.keys)

    def _prepare_data_by_key(self, key):
        data = {'concat_feature_numpy': [],
                'task_index': [],
                'action_index': [],
                'task_action_index': [],
                'attention_mask_numpy': [],
                'attention_num': [],
                'attention_box_str': [],
                'frame_name': [],
                'task_embedding': [],
                'action_embedding': [],
                }

        # task index
        [video_base_name, frame_index_start,
         frame_index_end] = key.strip().split('-')
        # key :"Subject1_rgbd_images_arranging_objects_0510175411-0000-0010"
        task_name = '_'.join(video_base_name.split('_')[3:5])
        task_index = self.task_index_dict[task_name]

        for frame_index in range(int(frame_index_start), int(frame_index_end)):
            self.tem_one_data = self.tem_one_data * 0

            # task index
            data['task_index'].append(task_index)
            data['task_embedding'].append(self.task_embeds[task_name])
            data['frame_name'].append(
                '{}-{:04d}'.format(video_base_name, frame_index))

            # action index
            action_key = '{}-{:04d}'.format(video_base_name, frame_index)
            action_index = self.action_index_dict[self.action_dict[action_key]]
            data['action_index'].append(action_index)
            data['action_embedding'].append(
                self.action_embeds[self.action_dict[action_key]])

            # task_action index
            data['task_action_index'].append(
                int(task_index * len(self.action_index_dict) + action_index))

            # raw image
            image_name = os.path.join(self.raw_image_path, video_base_name,
                                      '{:04d}.png'.format(frame_index))
            image = np.transpose(cv2.imread(image_name), (2, 0, 1))
            # from (1080,1920,3) to (3, 1080, 1920)
            self.tem_one_data[0:3, :, :] = image

            # skeleton
            self.skeleton_mask = self.skeleton_mask * [0]
            openpose_file = os.path.join(self.skeleton_ann_path,
                                         video_base_name,
                                         '{}_{:012d}_keypoints.json'.format(
                                             video_base_name, frame_index))
            with open(openpose_file, 'r') as output:
                skeletons = json.load(output)

            persons = skeletons['people']  # person is a list
            num = len(persons)
            if num > 0:
                person = self.chooseONEperson(persons)
                body = np.reshape(person['pose_keypoints_2d'], (18, 3))
                # body is a array
                body = self.confidence_filter(body, 0.1)
                for pair in self.skeleton_joint:
                    if body[pair[0], 2] != 0 and body[pair[1], 2] != 0:
                        # line segment is available
                        p1 = (int((body[pair[0], 0]) * self.input / self.W),
                              int((body[pair[0], 1]) * self.input / self.H))
                        p2 = (int((body[pair[1], 0]) * self.input / self.W),
                              int((body[pair[1], 1]) * self.input / self.H))
                        if p1 == p2:
                            continue
                        else:
                            self.skeleton_mask = cv2.line(self.skeleton_mask,
                                                          p1, p2, (255), 15)
                    else:
                        continue
            self.tem_one_data[3:4, :, :] = self.skeleton_mask

            # Read Optical Flow
            flow_name = os.path.join(self.flow_path, video_base_name,
                                     '{:04d}.npy'.format(frame_index))
            flow = np.load(flow_name)
            flow = np.transpose(flow, (2, 0, 1))
            self.tem_one_data[-2:, :, :] = flow * self.gray_degree

            self.tem_one_data = self.tem_one_data / self.gray_degree
            data['concat_feature_numpy'].append(self.tem_one_data)

            # attention
            attention_box = 'attention'
            self.attention_mask = self.attention_mask * [0]
            attention_ann_name = os.path.join(self.attention_ann_path,
                                              video_base_name,
                                              f'{video_base_name}-AttentionBox-'
                                              f'{frame_index:04d}.txt')

            with open(attention_ann_name, 'r') as att_obj_gt_txt:
                line = att_obj_gt_txt.readline()
                line = line.strip().split(' ')
            real_att_num = 0
            num_att = int(len(line) / 4)
            for i in range(num_att):
                b_lt = (int(line[i * 4]), int(line[i * 4 + 1]))  # (X1,Y1)
                b_rb = (int(line[i * 4 + 2]), int(line[i * 4 + 3]))
                y_min = int(min(b_lt[1], b_rb[1]) * self.input / self.H)
                y_max = int(max(b_lt[1], b_rb[1]) * self.input / self.H)
                x_min = int(min(b_lt[0], b_rb[0]) * self.input / self.W)
                x_max = int(max(b_lt[0], b_rb[0]) * self.input / self.W)
                x_len = int(x_min) - int(x_max)
                y_len = int(y_min) - int(y_max)
                if abs(x_len) < 1 or abs(y_len) < 1:
                    continue
                real_att_num += 1
                attention_box += ' {} {} {} {}'.format(x_min, y_min, x_max,
                                                       y_max)
                self.attention_mask[y_min:y_max, x_min:x_max] = 1

            data['attention_mask_numpy'].append(self.attention_mask)
            data['attention_num'].append(real_att_num)
            data['attention_box_str'].append(attention_box)

        return data

    @staticmethod
    def chooseONEperson(peoples):
        # peoples are the list of people from openpose, each people is a dict
        bestpeople = None
        max_confidece = 0
        for people in peoples:
            pose_keypoints_2d = people['pose_keypoints_2d']
            # array,  the number is 54 = 18*3 , (x, y , confidence)
            pose_keypoints_2d = np.reshape(pose_keypoints_2d, (18, 3))
            confidence = np.sum(pose_keypoints_2d, axis=0)[2]
            if confidence > max_confidece:
                max_confidece = confidence
                bestpeople = people
        return bestpeople

    @staticmethod
    def confidence_filter(data, con_threshold):
        # data is n*3 array
        # to filter the face, body, hand with low confidence
        n = data.shape[0]
        for i in range(n):
            con = data[i, 2]
            if con < con_threshold:
                data[i] = [0.0, 0.0, 0]
        return data

    @staticmethod
    def line2points(p1, p2):  # p1 is a tuple like (x1, y1)
        points = []
        x1 = p1[0]
        y1 = p1[1]
        x2 = p2[0]
        y2 = p2[1]
        det_x = abs(x1 - x2)
        det_y = abs(y1 - y2)
        N = max(det_x, det_y)
        if det_x != det_y:
            big_det = max(det_x, det_y)
            if big_det == det_x:
                step = (x2 - x1) / N
                for i in range(N):
                    x = int(x1 + i * step)
                    y = int(y1 + (y2 - y1) * (x - x1) / (
                            x2 - x1))  # triangle similar
                    points.append((x, y))
            if big_det == det_y:
                step = (y2 - y1) / N
                for i in range(N):
                    y = int(y1 + i * step)
                    x = int(x1 + (y - y1) * (x2 - x1) / (y2 - y1))
                    points.append((x, y))
        else:  # det_x == det_y
            step = (x2 - x1) / N
            if (det_x != 0):
                for i in range(N):
                    x = int(x1 + i * step)
                    y = int(y1 + (y2 - y1) * (x - x1) / (
                            x2 - x1))  # triangle similar
                    points.append((x, y))
            else:  # det_x == det_y == 0 same points
                for i in range(N):
                    print(
                        'error of line2points,error of line2points,'
                        'error of line2points,error of line2points')
                    points.append((x1, y1))
        return points


def main():
    aa = '/home/nan/dataset/TIA/raw_image'
    x = os.listdir(aa)
    y = {}
    for idx, name in enumerate(sorted(x)):
        y[name] = idx
    print(y)


if __name__ == '__main__':
    # main()
    from torch.utils.data import DataLoader
    from options.test_opt import TOptions

    opt = TOptions().parse()
    dataset_test = CustomDataset(opt, is_for_train=False)
    dataloader_test = DataLoader(dataset_test,
                                 batch_size=4,
                                 shuffle=False,
                                 num_workers=2,
                                 drop_last=True)

    for bs, test_bs in enumerate(dataloader_test):
        print(bs)
