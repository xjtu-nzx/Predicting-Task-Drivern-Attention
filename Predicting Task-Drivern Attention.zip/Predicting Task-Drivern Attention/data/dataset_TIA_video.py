import os.path
import cv2
import json
import random
import pickle
import numpy as np
from data.dataset_base import DatasetBase


class CustomDataset(DatasetBase):
    def __init__(self, opt, is_for_train):
        super(CustomDataset, self).__init__(opt, is_for_train)
        self.opt = opt
        self._is_for_train = is_for_train
        self.mode = 'train' if self._is_for_train else 'test'

        self.root_path = self._opt.data_root + 'TIA/'
        self.attention_ann_path = self.root_path + 'attention_annotation_name'
        self.skeleton_ann_path = self.root_path + 'skeleton'
        self.raw_image_path = self.root_path + 'raw_image_224'
        self.flow_path = self._opt.data_root + 'TIA_backup/flow'
        # self.flow_path = self.root_path + 'flow'

        self.task_embed_path = self.root_path + 'TIA_task_embedding.pickle'
        with open(self.task_embed_path, 'rb') as embed_file:
            self.task_embeds = pickle.load(embed_file)

        self.action_embed_path = self.root_path + 'TIA_action_embedding.pickle'
        with open(self.action_embed_path, 'rb') as embed_file:
            self.action_embeds = pickle.load(embed_file)

        self.action_path = self.root_path + 'action_annotation/'
        with open(os.path.join(self.action_path + 'action_dict.json'), 'r') as f:
            self.action_dict = json.load(f)

        # self._task_label = opt.task_label
        self._bottom_up_feature = self._opt.bottom_up_feature
        self.channel = self._opt.in_channels
        # self.IsVideo = self._opt.IsVideo

        self.H = 1080
        self.W = 1920
        self.input = 224
        self.gray_degree = 255
        self.temporal_num = self._opt.temporal_state
        self.train_skip_num = 10

        self.skeleton_mask = np.zeros((self.input, self.input))
        # self.objects_mask = np.zeros((self.input, self.input))
        self.label_mask = np.zeros((self.input, self.input))
        self.tem_one_data = np.zeros((self.channel, self.input, self.input))
        self.tem_one_label = np.zeros((self.input, self.input))

        self.skeleton_joint = [(1, 2), (1, 5), (2, 3), (3, 4), (5, 6), (6, 7),
                               (1, 8), (8, 9), (9, 10), (1, 11), (11, 12),
                               (12, 13),
                               (1, 0), (0, 14), (14, 16), (0, 15), (15, 17)]

        self.task_index_dict = {'c05_use_elevator': 4,
                                'c07_make_coffee': 6,
                                'c12_search_drawer': 11,
                                'c08_read_book': 7,
                                'c10_heat_food_with_microwave': 9,
                                'c14_open_door': 13,
                                'c06_pour_liquid_from_jug': 5,
                                'c09_throw_trash': 8,
                                'c11_use_computer': 10,
                                'c03_write_on_blackboard': 2,
                                'c13_move_bottle_to_dispenser': 12,
                                'c02_mop_floor': 1,
                                'c01_sweep_floor': 0,
                                'c04_clean_blackboard': 3}
        self.action_index_dict = {'take': 0,
                                  'mop': 1,
                                  'dehydrate': 2,
                                  'sweep': 3,
                                  'write': 4,
                                  'clean': 5,
                                  'use': 6,
                                  'pour': 7,
                                  'read': 8,
                                  'throw': 9,
                                  'heat': 10,
                                  'search': 11,
                                  'close': 12,
                                  'open': 13,
                                  'sit': 14,
                                  'move': 15,
                                  'make': 16,
                                  'null': 17}  # 18

        self.class_names_selected = [
            'backpack', 'umbrella', 'handbag', 'tie',
            'suitcase', 'frisbee', 'sports ball', 'bottle',
            'wine glass', 'cup', 'fork', 'knife',
            'spoon', 'bowl', 'banana', 'apple',
            'sandwich', 'orange', 'broccoli', 'carrot',
            'hot dog', 'pizza', 'donut', 'cake',
            'chair', 'potted plant', 'tv', 'laptop',
            'mouse', 'remote', 'keyboard', 'cell phone',
            'microwave', 'oven', 'toaster', 'sink',
            'refrigerator', 'book', 'clock', 'vase',
            'scissors', 'teddy bear', 'hair drier', 'toothbrush']

        self.keys = []
        self._prepare_keys()
        random.shuffle(self.keys)
        self.last_sample = None

    def __getitem__(self, index):
        assert (index < self._dataset_size)

        key = self.keys[index]
        data_dict = self._prepare_data_by_key(key)

        return data_dict

    def __len__(self):
        return self._dataset_size

    def _prepare_keys(self):
        temp_step = self.train_skip_num if self._is_for_train \
            else self.temporal_num

        file_list_path = os.path.join(self.root_path, f'{self.mode}_list.txt')
        with open(file_list_path, 'r') as file:
            lines = file.readlines()
            total_frame = len(lines)
            past_idx = -1
            for idx, line in enumerate(lines):
                if idx + self.temporal_num < total_frame:
                    start_line = line.strip()
                    [video_name_start, frame_index_start] = start_line.rsplit(
                        '-', 1)
                    end_line = lines[idx + self.temporal_num].strip()
                    [video_name_end, frame_index_end] = end_line.rsplit('-', 1)
                    real_length = int(frame_index_end) - int(frame_index_start)
                    if video_name_start == video_name_end and idx > past_idx \
                            and real_length == self.temporal_num:
                        tem_key = '{}-{}-{}'.format(video_name_start,
                                                    frame_index_start,
                                                    frame_index_end)
                        self.keys.append(tem_key)
                        past_idx = idx + temp_step

        # train and test length
        self._dataset_size = len(self.keys)

    def _prepare_data_by_key(self, key):
        data = {'concat_feature_numpy': [],
                'frame_name': [],
                'task_index': [],
                'action_index': [],
                'task_action_index': [],
                'attention_mask_numpy': [],
                'attention_num': [],
                'attention_box_str': [],
                'image_name': [],
                'task_embedding': [],
                'action_embedding': [],
                }

        [cate, video_base_name, frame_index_start,
         frame_index_end] = key.strip().split('-')
        # frame_index is from 0
        task_index = self.task_index_dict[cate]

        self.tem_one_data = self.tem_one_data * 0
        for frame_index in range(int(frame_index_start), int(frame_index_end)):
            # raw image
            raw_images = sorted(os.listdir(
                os.path.join(self.raw_image_path, cate, video_base_name)))
            image_name = os.path.join(self.raw_image_path, cate,
                                      video_base_name, raw_images[frame_index])
            image = np.transpose(cv2.imread(image_name), (2, 0, 1))
            # from (1080,1920,3) to (3, 1080, 1920)
            self.tem_one_data[0:3, :, :] = image
            # bottom-up feature
            if self._bottom_up_feature:
                # skeleton
                self.skeleton_mask = self.skeleton_mask * [0]
                openpose_file = os.path.join(self.skeleton_ann_path, cate,
                                             video_base_name,
                                             '{}_{:012d}_keypoints.json'.format(
                                                 video_base_name, frame_index))
                with open(openpose_file, 'r') as output:
                    skeletons = json.load(output)  # it is a list
                    assert len(skeletons) > 0
                    person = skeletons['people'][0]  # person is a dict
                    body = np.reshape(person['pose_keypoints_2d'], (18, 3))
                    body = self.confidence_filter(body, 0.1)
                    for pair in self.skeleton_joint:
                        if body[pair[0], 2] != 0 and body[pair[1], 2] != 0:
                            p1 = (int((body[pair[0], 0]) * self.input / self.W),
                                  int((body[pair[0], 1]) * self.input / self.H))
                            p2 = (int((body[pair[1], 0]) * self.input / self.W),
                                  int((body[pair[1], 1]) * self.input / self.H))
                            if p1 == p2:
                                continue
                            else:
                                self.skeleton_mask = cv2.line(
                                    self.skeleton_mask, p1, p2, (255), 15)
                        else:
                            continue
                self.tem_one_data[3:4, :, :] = self.skeleton_mask
                # flow
                flow_name = os.path.join(self.flow_path, cate, video_base_name,
                                         raw_images[frame_index][:-4] + '.npy')
                flow = np.load(flow_name)
                flow = np.transpose(flow, (2, 0, 1)) * self.gray_degree
                self.tem_one_data[-2:, :, :] = flow
            self.tem_one_data = (self.tem_one_data / self.gray_degree
                                 ).astype(np.float32)
            data['concat_feature_numpy'].append(self.tem_one_data)

            # attention
            self.tem_one_label = self.tem_one_label * [0]
            att_ann_name = os.path.join(self.attention_ann_path, cate,
                                        video_base_name,
                                        f'AttentionBoxes_{frame_index:04d}.json')
            with open(att_ann_name, 'r') as f:
                attentions = json.load(f)
            attention_box = 'attention'
            real_att_num = 0
            num_att = len(attentions)
            for i in range(num_att):
                each_att_obj = attentions[i]
                b_lt = (int(each_att_obj[1]), int(each_att_obj[2]))
                # # "1 dustpan 450 719 632 841 broom 576 705 664 813"
                b_rb = (int(each_att_obj[3]), int(each_att_obj[4]))

                y_min = int(min(b_lt[1], b_rb[1]) * self.input / self.H)
                y_max = int(max(b_lt[1], b_rb[1]) * self.input / self.H)
                x_min = int(min(b_lt[0], b_rb[0]) * self.input / self.W)
                x_max = int(max(b_lt[0], b_rb[0]) * self.input / self.W)

                x_min = max(0, x_min)
                y_min = max(0, y_min)
                x_max = min(x_max, 223)
                y_max = min(y_max, 223)

                x_len = int(x_min) - int(x_max)
                y_len = int(y_min) - int(y_max)

                if abs(x_len) < 1 or abs(y_len) < 1:
                    continue
                else:
                    real_att_num += 1
                    attention_box += ' {} {} {} {}'.format(x_min, y_min, x_max,
                                                           y_max)
                    self.tem_one_label[y_min:y_max, x_min:x_max] = 1

            # fill data
            data['task_index'].append(task_index)
            data['task_embedding'].append(self.task_embeds[cate])
            # action index
            action_key = '{}-{}-{}'.format(cate, video_base_name, frame_index)
            temp = self.action_dict.get(action_key, 'null')
            action_index = self.action_index_dict[temp]

            data['action_index'].append(action_index)
            data['action_embedding'].append(self.action_embeds[temp])

            data['task_action_index'].append(
                int(task_index * len(self.action_index_dict) + action_index))

            data['frame_name'].append(
                '{}-{}-{}'.format(cate, video_base_name, frame_index))
            data['attention_mask_numpy'].append(
                self.tem_one_label.astype(np.float32))
            data['attention_num'].append(real_att_num)
            data['attention_box_str'].append(attention_box)
            data['image_name'].append(raw_images[frame_index])

        return data

    def confidence_filter(self, data, con_threshold):
        # data is n*3 array
        # to filter the face, body, hand with low confidence
        n = data.shape[0]
        for i in range(n):
            con = data[i, 2]
            if con < con_threshold:
                data[i] = [0.0, 0.0, 0]
        return data

    def line2points(self, p1, p2):  # p1 is a tuple like (x1, y1)
        points = []
        x1 = p1[0]
        y1 = p1[1]
        x2 = p2[0]
        y2 = p2[1]
        det_x = abs(x1 - x2)
        det_y = abs(y1 - y2)
        N = max(det_x, det_y)
        if det_x != det_y:
            big_det = max(det_x, det_y)
            if big_det == det_x:
                step = (x2 - x1) / N
                for i in range(N):
                    x = int(x1 + i * step)
                    y = int(y1 + (y2 - y1) * (x - x1) / (
                            x2 - x1))  # triangle similar
                    points.append((x, y))
            if big_det == det_y:
                step = (y2 - y1) / N
                for i in range(N):
                    y = int(y1 + i * step)
                    x = int(x1 + (y - y1) * (x2 - x1) / (y2 - y1))
                    points.append((x, y))
        else:  # det_x == det_y
            step = (x2 - x1) / N
            if det_x != 0:
                for i in range(N):
                    x = int(x1 + i * step)
                    y = int(y1 + (y2 - y1) * (x - x1) / (
                            x2 - x1))  # triangle similar
                    points.append((x, y))
            else:  # det_x == det_y == 0 same points
                for i in range(N):
                    print(
                        'error of line2points,error of line2points,error of '
                        'line2points,error of line2points')
                    points.append((x1, y1))
        return points


def main():
    aa = '/home/nan/dataset/TIA/raw_image'
    x = os.listdir(aa)
    y = {}
    for idx, name in enumerate(sorted(x)):
        y[name] = idx
    print(y)


if __name__ == '__main__':
    # main()
    from torch.utils.data import DataLoader
    # from options.test_opt import TOptions
    from options.train_opt import TrainOptions

    opt = TrainOptions().parse()

    # generate saliency data
    save_path = '/data3/kaka/human_attention/data/Saliency/TIA/Train/'

    dataset_test = CustomDataset(opt, is_for_train=True)

    data_loader = DataLoader(dataset_test,
                             batch_size=1,
                             shuffle=False,
                             num_workers=2,
                             drop_last=False)

    print('start generating.')
    print(f'data len: {len(dataset_test)}')
    t = 0
    for bs, test_bs in enumerate(data_loader):
        print(bs)
        # if bs % 3 == 0:
        #     img_list = test_bs['concat_feature_numpy']
        #     att_list = test_bs['attention_mask_numpy']
        #     print(t)
        #
        #     l = len(img_list)
        #     img = img_list[l-1][:, :3, :, :].squeeze().permute(1, 2, 0).numpy()
        #     att = att_list[l-1].squeeze().numpy()
        #
        #     cv2.imwrite(os.path.join(save_path, f'Image/{str(t).zfill(6)}.png'),
        #                 img * 255)
        #     cv2.imwrite(os.path.join(save_path, f'Mask/{str(t).zfill(6)}.png'),
        #                 att * 255)
        #     t = t + 1
