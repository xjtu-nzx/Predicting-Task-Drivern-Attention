import argparse


class BaseOptions(object):
    def __init__(self):
        self._parser = argparse.ArgumentParser()
        self._initialized = False

    def initialize(self):
        self._parser.add_argument('--load_epoch', type=int, default=-1,
                                  help='which epoch to load? set to -1 to use '
                                       'latest cached model')
        self._parser.add_argument('--batch_size', type=int, default=8,
                                  help='input batch size')
        self._parser.add_argument('--temporal_state', type=int, default=8,
                                  help='step interval of video sampling.')
        self._parser.add_argument('--image_size', type=int, default=224,
                                  help='input image size')
        self._parser.add_argument('--gpu_ids', type=str, default='0,1,2,3',
                                  help='gpu ids: e.g. 0  0,1,2, 0,2. '
                                       'use -1 for CPU')

        # network
        self._parser.add_argument('--generator_name', type=str,
                                  default='human_attention_new',
                                  help='encoder_decoder_lstm, human_scene_task' 
                                       'encoder_decoder_conv3d, cls,'
                                       'human_attention_new_input')
        self._parser.add_argument('--temp_mode', type=str,
                                  default='ConvLSTM',
                                  help='Conv3D, ConvLSTM, ConvGRU')
        self._parser.add_argument('--use_embed', action='store_false',
                                  help='whether using action embedding for vae',
                                  default=True)
        self._parser.add_argument('--backbone', type=str,
                                  default='resnet18',
                                  help='resnet34, resnet50, vgg16, vgg19')

        # model
        self._parser.add_argument('--model', type=str,
                                  default='attention_model_video',
                                  help='cls, attention_model,'
                                       'attention_model_video')

        # check point
        self._parser.add_argument('--checkpoints_dir', type=str,
                                  default=
                                  '/data2/check_points/2020_HumanAttention/CAD',
                                  help='models are saved here')
        self._parser.add_argument('--name', type=str,
                                  default='TIA_TaskAction_embedding',
                                  help='name of the experiment. It decides '
                                       'where to store samples and models')

        # loss
        self._parser.add_argument('--WeightCELoss', type=bool, default=True,
                                  help='incorporate local  loss  training')
        self._parser.add_argument('--GlobalLoss', type=bool, default=True,
                                  help='incorporate global loss training')
        self._parser.add_argument('--TaskLoss', type=bool, default=True,
                                  help='incorporate task loss training')
        self._parser.add_argument('--TaskActionLoss', type=bool, default=True,
                                  help='incorporate task label in training')
        self._parser.add_argument('--TaskDecoderLoss', type=bool, default=False,
                                  help='incorporate task label in training')

        # Task(need to modify)
        self._parser.add_argument('--TaskNetwork', type=bool, default=True,
                                  help='incorporate task label in training')
        self._parser.add_argument('--TaskActionNetwork', type=bool,
                                  default=False,
                                  help='incorporate task label in training')

        # basic info
        self._parser.add_argument('--bottom_up_feature', type=bool,
                                  default=True,
                                  help='incorporate task label in training')
        self._parser.add_argument('--in_channels', type=int, default=6,
                                  help='incorporate task label in training')
        self._parser.add_argument('--task_num', type=int, default=9,
                                  help='TIA: 14;  CAD: 9')
        self._parser.add_argument('--action_num', type=int, default=10,
                                  help='TIA: 18; CAD120: 10')

        # dataset
        self._parser.add_argument('--dataset_mode', type=str,
                                  default='CAD_video',
                                  help='TIA_video, CAD_video')
        self._parser.add_argument('--data_root', type=str,
                                  default='/data2/datasets/',
                                  help='path to dataset root')

        self._parser.add_argument('--n_threads_train', default=8, type=int,
                                  help='# threads for loading data')
        self._parser.add_argument('--n_threads_test', default=8, type=int,
                                  help='# threads for loading data')
        self._initialized = True
