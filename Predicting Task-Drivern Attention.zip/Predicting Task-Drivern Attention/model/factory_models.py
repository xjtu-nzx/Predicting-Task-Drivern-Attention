
class ModelsFactory:
    def __init__(self):
        pass

    @staticmethod
    def get_by_name(model_name, *args, **kwargs):

        model = None
        if model_name == 'attention_model_video':
            from model.encoder_decoder import CustomModel
            model = CustomModel(*args, **kwargs)
			
        print("Model %s was created" % model.name)

        return model
