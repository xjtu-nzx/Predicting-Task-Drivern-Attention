import torch
import torch.nn as nn
from collections import OrderedDict
from torch import optim

from model.base import BaseModel
from networks.factory_networks import NetworksFactory
from loss.loss import weight_CELoss_Mean, outside_loss, weight_CELoss_batch, \
    inside_loss, dice_coefficient_loss, MseLoss, CrossEntropyLoss

torch.backends.cudnn.enabled = True
torch.backends.cudnn.benchmark = True


class CustomModel(BaseModel):
    def __init__(self, opt):
        super(CustomModel, self).__init__(opt)
        # self._name = 'attention_model_video'
        self._loss = None

        # create networks(encoder and decoder)
        self._init_create_networks()
        self._temporal_state = opt.temporal_state

        # init optimizer
        if self._is_train:
            self._init_train_optimizer()

        # load networks and optimizers
        if not self._is_train or self._opt.load_epoch > 0:
            self.load()

        # prefetch variables
        self._init_prefetch_inputs()

    def _init_create_networks(self):
        # generator network
        self._G = self._create_generator()
        # print(self._G)
        self._G = self._G.cuda(self._gpu_ids[0])

        if len(self._gpu_ids) == 1:
            self._G = self._G.to('cuda')
            self._G = self._G.to(self._gpu_ids[0])

        elif len(self._gpu_ids) > 1:
            self._G = nn.DataParallel(self._G, device_ids=self._gpu_ids)
        # self._G.init_weights()

    def _create_generator(self):
        # here, return is a network
        return NetworksFactory.get_by_name(self._opt.generator_name)

    def _init_train_optimizer(self):
        self._current_lr_G = self._opt.lr_G
        # initialize optimizers
        self._optimizer_G = optim.Adam(filter(lambda p: p.requires_grad,
                                              self._G.parameters()),
                                       lr=self._current_lr_G,
                                       betas=(self._opt.G_adam_b1,
                                              self._opt.G_adam_b2))
        # if len(self._gpu_ids) > 1:
        #     self._optimizer_G = nn.DataParallel(self._optimizer_G,
        #                                         device_ids=self._gpu_ids)

    def _init_prefetch_inputs(self):
        self._input_frame = self._Tensor(self._opt.batch_size,
                                         self._opt.in_channels,
                                         self._opt.image_size,
                                         self._opt.image_size)
        self._input_label = self._Tensor(self._opt.batch_size, 1,
                                         self._opt.image_size,
                                         self._opt.image_size)

    def set_input(self, input):  # input is train_batch
        self._input_frame = input['concat_feature_numpy']
        self._input_label = input['attention_mask_numpy']
        self.frame_name = input['frame_name']
        self.task_index = input['task_index']
        self.task_embeds = input['task_embedding']
        self.action_index = input['action_index']
        self.action_embeds = input['action_embedding']
        # self.frame_name = self.frame_name.cuda()
        # self.task_index = self.task_index.cuda()
        # self.frame_name = [i.cuda() for i in self.frame_name]
        # self.action_index = input['action_index']
        self.task_action_index = input['task_action_index']
        for i in range(self._temporal_state):  # change tensor type
            self._input_frame[i] = self._input_frame[i].float().cuda(
                self._gpu_ids[0])
            self._input_label[i] = self._input_label[i].float().cuda(
                self._gpu_ids[0])

            self.task_embeds[i] = self.task_embeds[i].float().cuda(
                self._gpu_ids[0])
            self.task_index[i] = self.task_index[i].long().cuda(
                self._gpu_ids[0])

            self.action_embeds[i] = self.action_embeds[i].float().cuda(
                self._gpu_ids[0])
            self.action_index[i] = self.action_index[i].long().cuda(
                self._gpu_ids[0])
            # self.task_action_index[i] = self.task_action_index[i].cuda(
            #     self._gpu_ids[0])

        return True

    def set_train(self):
        self._G.train()
        self.epoch_total = 0
        self.epoch_correct = 0
        self._epoch_acc = 0
        self._is_train = True

    def set_eval(self):
        self._G.eval()
        self.epoch_total = 0
        self.epoch_correct = 0
        self._epoch_acc = 0
        # by chance
        # self.task_acc = np.zeros((14, 1))
        # self.task_total = np.zeros((14, 1))
        # self.chance_acc = np.zeros((14, 1))
        self._is_train = False

    def train_forward_backward(self):  # for training
        if self._is_train:
            result = self.G_forward_and_loss_compute()
            self._optimizer_G.zero_grad()
            result['loss'].backward(retain_graph=True)
            self._optimizer_G.step()

    def test_forward(self):  # for testing
        if not self._is_train:
            self.G_forward_and_loss_compute()

    def G_forward_and_loss_compute(self):  # return training loss
        # forward and network output
        output = self._G.forward(self._input_frame, self.action_embeds,
                                 self.task_embeds)
        # output = self._G.forward(self._input_frame, self.action_embeds)
        attention_hm_predict = output['att_map']
        vae_loss = output['vae_loss']

        if self._opt.TaskActionNetwork:
            self.task_action_prediction = output['task_action_predict']

        elif self._opt.TaskNetwork:
            self.task_prediction = output['task_predict']

        self.task_loss = self._Tensor([0])
        self.WeightCELoss = self._Tensor([0])
        self.Dice_loss = self._Tensor([0])

        for i_step in range(self._opt.temporal_state):
            gt = self._input_label[i_step].squeeze()
            pre = attention_hm_predict[i_step].squeeze()
            # task Loss
            if self._opt.TaskLoss:
                # self.task_loss += CrossEntropyLoss(
                #     self.task_prediction[i_step],
                #     self.task_index[i_step])
                self.task_loss += CrossEntropyLoss(
                    self.task_prediction[i_step],
                    self.action_index[i_step])
                # self.task_loss += CrossEntropyLoss(
                #     self.task_prediction[i_step],
                #     self.task_action_index[i_step])

                self.task_loss += vae_loss[i_step].mean()

            # pixel-wise WeightCELoss
            if self._opt.WeightCELoss:
                self.WeightCELoss += weight_CELoss_Mean(gt, pre)

            # dice_coefficient_loss
            if self._opt.GlobalLoss:
                self.Dice_loss += dice_coefficient_loss(gt, pre)

        self.task_loss = 0.1 * self.task_loss

        self._loss = self.Dice_loss + self.WeightCELoss + self.task_loss

        result = {
            'loss': self._loss,
            'heat_map': attention_hm_predict,
            'img': output["img"],
            'pose': output["pose"],
            'motion': output["motion"],

        }

        return result

    def get_current_scalars(self):  # current learning rate
        return OrderedDict([('lr_G', self._current_lr_G)])

    def save(self, label):
        # save networks
        self._save_network(self._G, 'G', label)

        # save optimizers
        self._save_optimizer(self._optimizer_G, 'G', label)

    def load(self):
        load_epoch = self._opt.load_epoch

        # load G
        self._load_network(self._G, 'G', load_epoch)

        if self._is_train:
            self._load_optimizer(self._optimizer_G, 'G', load_epoch)

    def update_learning_rate(self):
        # updated learning rate G, for example from 0.2 to 0.2-0.2/10
        lr_decay = self._opt.lr_G / self._opt.nepochs_decay  #
        self._current_lr_G -= lr_decay
        for param_group in self._optimizer_G.param_groups:
            param_group['lr'] = self._current_lr_G
        print('update G learning rate: %f -> %f' % (
            self._current_lr_G + lr_decay, self._current_lr_G))

    def get_current_errors(self):
        loss_dict = OrderedDict()
        if self._opt.GlobalLoss:
            loss_dict['Diceloss'] = self.Dice_loss.item()
        if self._opt.WeightCELoss:
            loss_dict['weightCE'] = self.WeightCELoss.item()
        if self._opt.TaskLoss:
            loss_dict['task_loss'] = self.task_loss.item()
        if self._opt.TaskDecoderLoss:
            loss_dict['TaskDecoderLoss'] = self.task_decoder_loss.item()
        loss_dict['total_loss'] = self._loss.item()
        return loss_dict
