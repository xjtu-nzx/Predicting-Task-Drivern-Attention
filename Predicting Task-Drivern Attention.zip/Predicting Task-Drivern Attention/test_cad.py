import os
import json
import cv2
import shutil
import numpy as np
import torch

from utils.util import tensor2im
from utils.util import IOU_compute
from options.test_opt import TOptions
from data.factory_dataloader import CustomDatasetDataLoader
from model.factory_models import ModelsFactory

import matplotlib.pyplot as plt


class Test:
    def __init__(self):
        self._opt = TOptions().parse()
        self._save_path = os.path.join(self._opt.checkpoints_dir,
                                       self._opt.name)

        self.img_path = '/data2/datasets/CAD120/raw_image_224/'

        test_loader = CustomDatasetDataLoader(self._opt, is_for_train=False)
        self.data_test = test_loader.load_data()
        self.data_test_size = len(test_loader)

        self.data_name = self._opt.dataset_mode
        if self.data_name.startswith('CAD'):
            self.pattern = 'CAD'
            self.data_path = self._opt.data_root + 'CAD120/'
            self.H = 480
            self.W = 640
            self.task_index_dict = {0: 'arranging_objects',
                                    1: 'cleaning_objects',
                                    2: 'making_cereal',
                                    3: 'microwaving_food',
                                    4: 'picking_objects',
                                    5: 'stacking_objects',
                                    6: 'taking_food',
                                    7: 'taking_medicine',
                                    8: 'unstacking_objects'}

        elif self.data_name.startswith('TIA'):
            self.pattern = 'TIA'
            self.data_path = self._opt.data_root + 'TIA/'
            self.H = 1080
            self.W = 1920
            self.task_index_dict = {0: 'c01_sweep_floor',
                                    1: 'c02_mop_floor',
                                    2: 'c03_write_on_blackboard',
                                    3: 'c04_clean_blackboard',
                                    4: 'c05_use_elevator',
                                    5: 'c06_pour_liquid_from_jug',
                                    6: 'c07_make_coffee',
                                    7: 'c08_read_book',
                                    8: 'c09_throw_trash',
                                    9: 'c10_heat_food_with_microwave',
                                    10: 'c11_use_computer',
                                    11: 'c12_search_drawer',
                                    12: 'c13_move_bottle_to_dispenser',
                                    13: 'c14_open_door'}
        else:
            pass

        self.is_test_video = 1

        self.is_test_using_object_detection = 0
        self.is_test_using_cross_criterion = 1
        self.is_visual_and_save = 0
        self.is_save = 1

        self.focus_loss_IOU_threshold = 0.6
        self.IOUMetric_threshold = 0.5
        self._temporal_state = self._opt.temporal_state
        self.image_size = 224

        # format
        self.f_statistics = None
        self.no_detection_num = 0
        self.error_by_detection_num = 0
        self.img_name = None

        self.start_epoch = 1
        self.epoch_index = 0
        print('here is okay')
        self.run()

    def run(self):
        exp_path = os.path.join(self._save_path, 'exp_result_gt')
        if not os.path.exists(exp_path):
            os.mkdir(exp_path)

        shutil.copyfile('./networks/human_attention.py',
                        os.path.join(exp_path, 'network.py'))
        shutil.copyfile('./networks/task_encoding.py',
                        os.path.join(exp_path, 'task.py'))
        shutil.copyfile('./options/base_opt.py',
                        os.path.join(exp_path, 'opt.py'))

        if self.is_save:
            if not os.path.exists(os.path.join(exp_path, 'heatmap')):
                os.mkdir(os.path.join(exp_path, 'heatmap'))

            if not os.path.exists(os.path.join(exp_path, 'attentional_object')):
                os.mkdir(os.path.join(exp_path, 'attentional_object'))

        # result txt
        if self.is_test_using_cross_criterion:
            if self.is_test_using_object_detection:
                result_save_name = os.path.join(
                    exp_path, 'result_CrossMetric_Object_Detection.txt')
            else:
                result_save_name = os.path.join(
                    exp_path, 'result_CrossMetric_Object_Annotation.txt')
        else:
            result_save_name = os.path.join(exp_path, 'result_IOUMetric.txt')

        f_w = open(result_save_name, 'a')
        f_w.write('******************  new experiments *******************\n')
        f_w.close()

        # experiment statistics txt
        if self.is_test_using_cross_criterion:
            if self.is_test_using_object_detection:
                experiment_statistics_name = os.path.join(
                    exp_path, 'statistics-Cross-ObjDet.txt')
            else:
                experiment_statistics_name = os.path.join(
                    exp_path, 'statistics-Cross-ObjAnnotation.txt')
        else:
            experiment_statistics_name = os.path.join(exp_path,
                                                      'statistics-IOU.txt')
        self.f_statistics = open(experiment_statistics_name, 'w')
        self.f_statistics.write(
            '***************** new experiments *********************\n')
        self.f_statistics.write(
            '**********is_test_using_cross_criterion == {}**********\n'.format(
                self.is_test_using_cross_criterion))
        self.f_statistics.write(
            '*************is_test_using_object_detection == {}\n'.format(
                self.is_test_using_object_detection))

        # all checkpoints
        all_networks = os.listdir(os.path.join(self._save_path))
        max_number = 0
        for each_file in all_networks:
            if each_file.startswith('net'):
                idx = int(each_file.strip().split('_')[2])
                if idx > max_number:
                    max_number = idx

        # evaluate using each epoch
        # for i_epoch in range(self.start_epoch, max_number + 1):
        for i_epoch in [2]:
            print('===========================================================')
            print(f'start testing epoch: {i_epoch}.')
            self.epoch_index = i_epoch
            self.no_detection_num = 0
            self.error_by_detection_num = 0
            self.f_statistics.write(
                '---------------------- epoch {} ----------------- \n'.format(
                    i_epoch))
            f_w = open(result_save_name, 'a')
            f_w.write(
                '---------------------- epoch {} ----------------- \n'.format(
                    i_epoch))
            self._opt.load_epoch = i_epoch

            model = ModelsFactory.get_by_name(self._opt.model, self._opt)

            task_total_frames = {}
            task_correct_frames = {}

            #  all batch
            for i_val_batch, val_batch in enumerate(self.data_test):
                print(f'batch:{i_val_batch}/{len(self.data_test)}')

                model.set_input(val_batch)

                task_indexes = model.task_index  # list 16
                frame_names = model.frame_name  # list 16
                if self.pattern == 'TIA':
                    img_names = val_batch['image_name']

                batch_output = model.G_forward_and_loss_compute()
                # batch_predict_heatmap = batch_output['heat_map']

                if self.is_test_video == 1:
                    for step in range(self._temporal_state):
                        for i in range(self._opt.batch_size):
                            heat_map = batch_output['heat_map'][step][i]
                            self.img_hm = batch_output['img'][step][i]
                            self.pose_hm = batch_output['pose'][step][i]
                            self.motion_hm = batch_output['motion'][step][i]

                            frame_name = frame_names[step][i].strip()
                            task_index = int(task_indexes[step][i])

                            if task_index not in task_total_frames:
                                task_total_frames[task_index] = 1
                            else:
                                task_total_frames[task_index] += 1
                            # correct dict
                            if task_index not in task_correct_frames:
                                task_correct_frames[task_index] = 0

                            if self.pattern == 'TIA':
                                self.img_name = img_names[step][i]

                            if self.is_test_using_cross_criterion:
                                is_correct = \
                                    self.is_correct_using_cross_criterion_new(
                                        self.pattern, frame_name, heat_map)
                            else:
                                is_correct = self.is_correct_iou_metric(
                                    self.pattern, frame_name, heat_map)

                            if is_correct:
                                task_correct_frames[task_index] += 1

                elif self.is_test_video == 0:  # for images
                    for i in range(self._opt.batch_size):
                        heat_map = batch_output['heat_map'][i]

                        frame_name = frame_names[i].strip()
                        task_index = int(task_indexes[i])
                        if task_index not in task_total_frames:
                            task_total_frames[task_index] = 1
                        else:
                            task_total_frames[task_index] += 1

                        if task_index not in task_correct_frames:
                            task_correct_frames[task_index] = 0

                        # is correct
                        if self.is_test_using_cross_criterion:
                            is_correct = \
                                self.is_correct_using_cross_criterion_new(
                                    self.pattern, frame_name, heat_map)
                        else:
                            is_correct = self.is_correct_iou_metric(
                                self.pattern, frame_name, heat_map)
                        if is_correct:
                            task_correct_frames[task_index] += 1

            # write the statistics
            self.f_statistics.write('No detected object number  = {}\n'.format(
                self.no_detection_num))
            self.f_statistics.write(
                'Error by object detection number  = {}\n'.format(
                    self.error_by_detection_num))

            # write the precision for each epoch
            total_correct = 0
            total_total = 0
            print(task_correct_frames, task_total_frames)
            for key in sorted(task_correct_frames.keys()):
                f_w.write(
                    '{}-, precision = {:.3f}, correct num = {}, '
                    'total_number = {}, --- {}\n'.format(
                        key,
                        float(task_correct_frames[key] /
                              task_total_frames[key]),
                        task_correct_frames[key],
                        task_total_frames[key],
                        self.task_index_dict[key])
                )
                total_correct += task_correct_frames[key]
                total_total += task_total_frames[key]

            f_w.write('overall precision:{:.3f}\n'.format(
                float(total_correct / total_total)))

    def is_correct_iou_metric(self, pattern, frame_name, heatmap):
        is_correct = 0
        # load object detection
        flag, objects = self.load_object_detection(pattern, frame_name)
        if flag == 0:
            pass
        else:
            # find the best object
            # [score, x1, y1, x2, y2, name] in 224*224 image
            best_obj = self.find_best_one_obj(objects, heatmap)
            best_bbox = [best_obj[1] * self.W / self.image_size,
                         best_obj[2] * self.H / self.image_size,
                         best_obj[3] * self.W / self.image_size,
                         best_obj[4] * self.H / self.image_size]

            # load attentions
            attentions = self.load_attentions(pattern, frame_name)
            att_num = len(attentions)
            assert att_num == 1 or att_num == 2
            for att in attentions:
                bbox_att = att[1:5]
                iou = IOU_compute(best_bbox, bbox_att)
                if iou > self.IOUMetric_threshold:
                    is_correct = 1
                    break

        return is_correct

    def load_object_detection(self, pattern, frame_name):
        flag = 1
        path_name = None
        if pattern == 'CAD':
            path = self.data_path + 'CAD120_focusloss_detection'
            [cate, frame_index] = frame_name.split('-')
            path_name = os.path.join(path, cate,
                                     '{}.json'.format(frame_index))

        elif pattern == 'TIA':
            path = self._opt.data_root + 'TIA_backup/focusloss_detection'
            [cate, video_base_name, frame_index] = frame_name.split('-')
            path_name = os.path.join(path, cate, video_base_name,
                                     f'{self.img_name[:-3]}json')

        if not os.path.exists(path_name):
            flag = 0
            filtered_objects = []

        else:
            with open(path_name, 'r') as f:
                objects = json.load(f)
            filtered_objects = self.filter_objtect(objects)
            obj_num = len(filtered_objects)
            if obj_num < 1:
                flag = 0
        return flag, filtered_objects

    def load_annotated_objects(self, pattern, frame_name):
        if pattern == 'CAD':
            [video_base_name, frame_index] = frame_name.split("-")
            root_path = self.data_path + 'allobjects_annotation_name'
            all_objs_name = os.path.join(root_path, video_base_name,
                                         "all_objects_{:04d}.json".format(
                                             int(frame_index) + 1))
            with open(all_objs_name, 'r') as f:
                all_objs = json.load(f)
            return all_objs

    def is_correct_using_cross_criterion_new(self, pattern, frame_name,
                                             heatmap):
        is_correct = False
        flag = 0
        # load object detection
        if self.is_test_using_object_detection:
            flag1, objects = self.load_object_detection(pattern, frame_name)
            flag = flag1
        else:
            objects = self.load_annotated_objects(pattern, frame_name)
            if len(objects) > 0:
                flag = 1

        if flag == 0:
            self.no_detection_num += 1
            self.f_statistics.write(
                'No object Detected:                               {}\n'.format(
                    frame_name))
            if self.is_save:
                [video_base_name, frame_index] = frame_name.split('-')
                img_path = os.path.join(self.img_path, video_base_name,
                                        f'{frame_index}.png')
                self.image = cv2.imread(img_path)

                # save heat map image
                heat_map_image = tensor2im(heatmap.detach())
                save_name = self.heat_map_save_name(pattern, frame_name)
                heatmap = cv2.applyColorMap(np.uint8(heat_map_image),
                                            cv2.COLORMAP_JET)
                # temp = 0.5 * self.image + 0.5 * heatmap
                temp = self.image + 0.4 * heatmap
                # temp = (temp - temp.min()) / (temp.max() - temp.min())
                cv2.imwrite(save_name, temp)

        else:
            # here has guaranteed the object detection is existing
            # find the best object
            best_obj = self.find_best_one_obj(objects, heatmap)
            best_obj_center_point = [int(
                0.5 * (best_obj[1] + best_obj[3]) * self.W / self.image_size),
                int(0.5 * (best_obj[2] + best_obj[
                    4]) * self.H / self.image_size)]
            # load attentions
            attentions = self.load_attentions(pattern, frame_name)
            att_num = len(attentions)
            assert att_num == 1 or att_num == 2

            # find human head location
            is_exist_head, head_point = self.find_head_location(frame_name)
            if is_exist_head:
                self.point_on_bottom_edge = self.two_point_to_downedge_point(
                    best_obj_center_point, head_point, self.H, self.W)
                gaze_line = [self.point_on_bottom_edge, head_point]
                for attention in attentions:
                    four_lines = self.four_lines_of_box(attention[1:])
                    for each_line in four_lines:
                        is_cross = self.IsIntersec(gaze_line[0], gaze_line[1],
                                                   each_line[0], each_line[1])
                        if is_cross:
                            is_correct = True
                            break

                # object detection leads to failture
                obj_det_error_flag = 1
                for attention in attentions:
                    four_lines = self.four_lines_of_box(attention[1:])
                    for obj in objects:
                        obj_center_point = [int(0.5 * (obj[1] + obj[3])),
                                            int(0.5 * (obj[2] + obj[4]))]
                        point_on_bottom_edge = self.two_point_to_downedge_point(
                            obj_center_point, head_point, self.H, self.W)
                        gaze_line = [point_on_bottom_edge, head_point]
                        for each_line in four_lines:
                            is_cross = self.IsIntersec(gaze_line[0],
                                                       gaze_line[1],
                                                       each_line[0],
                                                       each_line[1])
                            if is_cross:
                                obj_det_error_flag = 0
                                break
                if obj_det_error_flag:
                    self.error_by_detection_num += 1
                    self.f_statistics.write(
                        'Error by Object Detection                 {}\n'.format(
                            frame_name))
            else:  # head not exist
                if self.epoch_index == 1:
                    self.f_statistics.write(
                        'No Head:                                  {}\n'.format(
                            frame_name))

            # save
            if self.is_save:
                [video_base_name, frame_index] = frame_name.split('-')
                img_path = os.path.join(self.img_path, video_base_name,
                                        f'{frame_index}.png')
                self.image = cv2.imread(img_path)

                [video_base_name, frame_index] = frame_name.split('-')
                save_dir = os.path.join(
                    self._opt.checkpoints_dir, self._opt.name,
                    'exp_result_gt', 'heatmap', video_base_name,
                )
                if not os.path.exists(save_dir):
                    os.makedirs(save_dir, exist_ok=True)
                    if not os.path.exists(os.path.join(save_dir, 'fv')):
                        os.mkdir(os.path.join(save_dir, 'fv'))
                    if not os.path.exists(os.path.join(save_dir, 'fs')):
                        os.mkdir(os.path.join(save_dir, 'fs'))
                    if not os.path.exists(os.path.join(save_dir, 'fm')):
                        os.mkdir(os.path.join(save_dir, 'fm'))
                # fv
                heatmap = cv2.applyColorMap(
                    np.uint8(tensor2im(self.img_hm.unsqueeze(0))),
                    cv2.COLORMAP_JET
                )
                img_hm = cv2.resize(
                    heatmap, (self.image_size, self.image_size),
                    interpolation=cv2.INTER_CUBIC)
                temp = 0.5 * self.image + 0.5 * img_hm
                save_name = os.path.join(
                    save_dir, 'fv/{:04d}.png'.format(int(frame_index))
                )
                cv2.imwrite(save_name, temp)

                # fs
                heatmap = cv2.applyColorMap(
                    np.uint8(tensor2im(self.pose_hm.unsqueeze(0))),
                    cv2.COLORMAP_JET
                )
                img_hm = cv2.resize(
                    heatmap, (self.image_size, self.image_size),
                    interpolation=cv2.INTER_CUBIC)
                temp = 0.5 * self.image + 0.5 * img_hm
                save_name = os.path.join(
                    save_dir, 'fs/{:04d}.png'.format(int(frame_index))
                )
                cv2.imwrite(save_name, temp)

                # fm
                heatmap = cv2.applyColorMap(
                    np.uint8(tensor2im(self.motion_hm.unsqueeze(0))),
                    cv2.COLORMAP_JET
                )
                img_hm = cv2.resize(
                    heatmap, (self.image_size, self.image_size),
                    interpolation=cv2.INTER_CUBIC)
                temp = 0.5 * self.image + 0.5 * img_hm
                save_name = os.path.join(
                    save_dir, 'fm/{:04d}.png'.format(int(frame_index))
                )
                cv2.imwrite(save_name, temp)
                #
                # # save heat map image
                # heat_map_image = tensor2im(heatmap.detach())
                # save_name = self.heat_map_save_name(pattern, frame_name)
                # heatmap = cv2.applyColorMap(np.uint8(heat_map_image),
                #                             cv2.COLORMAP_JET)
                # # temp = 0.5 * self.image + 0.5 * heatmap
                # temp = self.image + 0.4 * heatmap
                # # temp = (temp - temp.min()) / (temp.max() - temp.min())
                # cv2.imwrite(save_name, temp)
                #
                # # save best object
                # best_attentional_object = [best_obj[5], int(
                #     best_obj[1] * self.W / self.image_size),
                #                            int(best_obj[
                #                                    2] * self.H / self.image_size),
                #                            int(best_obj[
                #                                    3] * self.W / self.image_size),
                #                            int(best_obj[
                #                                    4] * self.H / self.image_size)]
                # save_name = self.attention_object_save_name(pattern, frame_name)
                # with open(save_name, 'w') as f:
                #     json.dump(best_attentional_object, f)
                #
                # # draw
                # self.draw_bounding_box_on_image(attentions, att=True,
                #                                 thickness=1)
                # color = (255, 0, 0)  # blue
                # cv2.rectangle(self.image,
                #               (int(best_obj[1]), int(best_obj[2])),
                #               (int(best_obj[3]), int(best_obj[4])),
                #               color, 1)
                # save_name = self.visual_save(pattern, frame_name)
                # cv2.imwrite(save_name, self.image)
        return is_correct

    def draw_bounding_box_on_image(self, obj_list, att=True, thickness=2):
        if att:
            color = [0, 0, 255]
        else:
            color = [0, 255, 0]
        for obj in obj_list:
            [key, x1, y1, x2, y2] = obj[:5]
            x1 = int(int(x1) / self.W * self.image_size)
            x2 = int(int(x2) / self.W * self.image_size)
            y1 = int(int(y1) / self.H * self.image_size)
            y2 = int(int(y2) / self.H * self.image_size)
            cv2.rectangle(self.image, (x1, y1), (x2, y2), color, thickness)

    def visual_save(self, pattern, frame_name):
        if pattern == 'CAD':
            [video_base_name, frame_index] = frame_name.split('-')
            if not os.path.exists(
                    os.path.join(self._opt.checkpoints_dir, self._opt.name,
                                 'exp_result', 'quality')):
                os.mkdir(os.path.join(self._opt.checkpoints_dir, self._opt.name,
                                      'exp_result', 'quality'))
            if not os.path.exists(
                    os.path.join(self._opt.checkpoints_dir, self._opt.name,
                                 'exp_result',
                                 'quality', video_base_name)):
                os.mkdir(os.path.join(self._opt.checkpoints_dir, self._opt.name,
                                      'exp_result',
                                      'quality', video_base_name))

            heat_map_save_name = os.path.join(self._opt.checkpoints_dir,
                                              self._opt.name,
                                              'exp_result',
                                              'quality', video_base_name,
                                              '{:04d}.png'.format(
                                                  int(frame_index)))
            return heat_map_save_name

    def heat_map_save_name(self, pattern, frame_name):
        if pattern == 'CAD':
            [video_base_name, frame_index] = frame_name.split('-')
            # [people, video, view, frame_index] = frame_name.split("/")
            if not os.path.exists(
                    os.path.join(self._opt.checkpoints_dir, self._opt.name,
                                 'exp_result',
                                 'heatmap', video_base_name)):
                os.mkdir(os.path.join(self._opt.checkpoints_dir, self._opt.name,
                                      'exp_result',
                                      'heatmap', video_base_name))
            heat_map_save_name = os.path.join(self._opt.checkpoints_dir,
                                              self._opt.name,
                                              'exp_result',
                                              'heatmap', video_base_name,
                                              '{:04d}.png'.format(
                                                  int(frame_index)))
            return heat_map_save_name

    def attention_object_save_name(self, pattern, frame_name):
        if pattern == 'CAD':
            [video_base_name, frame_index] = frame_name.split('-')
            if not os.path.exists(
                    os.path.join(self._opt.checkpoints_dir, self._opt.name,
                                 'exp_result',
                                 'attentional_object', video_base_name)):
                os.mkdir(os.path.join(self._opt.checkpoints_dir, self._opt.name,
                                      'exp_result',
                                      'attentional_object',
                                      video_base_name))

            save_name = os.path.join(self._opt.checkpoints_dir, self._opt.name,
                                     'exp_result',
                                     'attentional_object', video_base_name,
                                     '{:04d}.json'.format(int(frame_index)))

            return save_name

    def load_attentions(self, pattern, frame_name):
        if pattern == 'CAD':
            path = self.data_path + 'attention_annotation_name'
            [video_base_name, frame_index] = frame_name.split("-")
            name = os.path.join(path, video_base_name,
                                'attention-{}.json'.format(frame_index))
            with open(name, 'r') as file:
                attentions = json.load(file)
            return attentions
        elif pattern == 'TIA':
            path = self.data_path + 'attention_annotation_name'
            [task, video_base_name, frame_index] = frame_name.split("-")
            name = os.path.join(path, task, video_base_name,
                                f'AttentionBoxes_{frame_index.zfill(4)}.json')
            with open(name, 'r') as file:
                attentions = json.load(file)
            return attentions

    @staticmethod
    def cross(p1, p2, p3):
        x1 = p2[0] - p1[0]
        y1 = p2[1] - p1[1]
        x2 = p3[0] - p1[0]
        y2 = p3[1] - p1[1]
        return x1 * y2 - x2 * y1

    def IsIntersec(self, p1, p2, p3, p4):

        if (max(p1[0], p2[0]) >= min(p3[0], p4[0])
                and max(p3[0], p4[0]) >= min(p1[0], p2[0])
                and max(p1[1], p2[1]) >= min(p3[1], p4[1])
                and max(p3[1], p4[1]) >= min(p1[1], p2[1])):

            if (self.cross(p1, p2, p3) * self.cross(p1, p2, p4) <= 0
                    and self.cross(p3, p4, p1) * self.cross(p3, p4, p2) <= 0):
                D = 1
            else:
                D = 0
        else:
            D = 0
        return D

    @staticmethod
    def islineintersect(line1, line2):

        is_corss = 1
        i1 = [min(line1[0][0], line1[1][0]), max(line1[0][0], line1[1][0])]
        i2 = [min(line2[0][0], line2[1][0]), max(line2[0][0], line2[1][0])]
        ia = [max(i1[0], i2[0]), min(i1[1], i2[1])]
        if max(line1[0][0], line1[1][0]) < min(line2[0][0], line2[1][0]):
            is_corss = 0
            # return False
        # if
        m1 = (line1[1][1] - line1[0][1]) * 1. / max((line1[1][0] - line1[0][0]),
                                                    1) * 1.
        m2 = (line2[1][1] - line2[0][1]) * 1. / max((line2[1][0] - line2[0][0]),
                                                    1) * 1.
        if m1 == m2:
            is_corss = 0
            # return False
        b1 = line1[0][1] - m1 * line1[0][0]
        b2 = line2[0][1] - m2 * line2[0][0]
        x1 = (b2 - b1) / (m1 - m2)
        if (x1 < max(i1[0], i2[0])) or (x1 > min(i1[1], i2[1])):
            is_corss = 0
            # return False
        # return True
        return is_corss

    @staticmethod
    def four_lines_of_box(attention):
        x1, y1, x2, y2 = int(attention[0]), int(attention[1]), int(
            attention[2]), int(attention[3])
        lines = []
        p11 = (x1, y1)
        p22 = (x1, y2)
        lines.append((p11, p22))  # left

        p11 = (x1, y1)
        p22 = (x2, y1)
        lines.append((p11, p22))  # top

        p11 = (x2, y2)
        p22 = (x2, y1)
        lines.append((p11, p22))  # right

        p11 = (x1, y2)
        p22 = (x2, y2)
        lines.append((p11, p22))  # down

        return lines

    @staticmethod
    def two_point_to_downedge_point(p1, p2, h, w):
        x1 = p1[0]
        y1 = p1[1]
        x2 = p2[0]
        y2 = p2[1]

        deta_y = abs(y2 - y1)
        if deta_y < 5:
            return_p = (w, min(y1, y2))
        else:
            if y1 > y2:
                p_upper = [x2, y2]
                p_down = [x1, y1]
            else:
                p_upper = [x1, y1]
                p_down = [x2, y2]

            X = p_down[0] - (p_upper[0] - p_down[0]) * (p_down[1] - h) / (
                    p_upper[1] - p_down[1])
            X = int(X)
            return_p = (X, h)

        return return_p

    def find_head_location(self, frame_name):
        is_exist_head = 1
        X = 0
        Y = 0
        head_list = [0, 14, 15, 16, 17]
        if self.data_name.startswith('CAD'):
            [cate, frame_index] = frame_name.split('-')
            skeleton_path = self.data_path + 'skeleton_openpose_json'
            openpose_file = os.path.join(skeleton_path, cate,
                                         '{}_{:012d}_keypoints.json'
                                         .format(cate, int(frame_index)))
        elif self.data_name.startswith('TIA'):
            [cate, video_base_name, frame_index] = frame_name.split('-')
            skeleton_path = self.data_path + 'skeleton'
            openpose_file = os.path.join(skeleton_path, cate, video_base_name,
                                         f'{video_base_name}_'
                                         f'{int(frame_index):012d}_'
                                         f'keypoints.json')

        # heat location
        head_points = []
        with open(openpose_file, 'r') as output:
            skeletons = json.load(output)  # it is a list
            persons = skeletons['people']  # person is a list
        num = len(persons)
        if num == 0:
            is_exist_head = 0
        else:
            person = persons[0]
            body = np.reshape(person['pose_keypoints_2d'],
                              (18, 3))  # body is a array
            # body = self.confidence_filter(body, 0.1)
            # self.draw_body(cv_image,body)
            for i in head_list:
                x = body[i, 0]
                y = body[i, 1]
                if x != 0 and y != 0:
                    head_points.append((x, y))

            head_points_num = len(head_points)
            if head_points_num == 0:
                is_exist_head = 0
            else:
                for (x, y) in head_points:
                    X += x
                    Y += y
                X = int(float(X / head_points_num))
                Y = int(float(Y / head_points_num))
        point = [X, Y]

        return is_exist_head, point

    def is_correct_using_detected_objects(self, frame_name, heatmap):
        assert heatmap.size()[0] == 1 and heatmap.size()[1] == 224, '{}'.format(
            heatmap.size())
        is_correct = False
        # visual heatmap
        if self.is_visual_and_save:
            heatmap_image = tensor2im(heatmap.detach())
            cv2.imshow('2', heatmap_image)

        # CAD
        if self.data_name.startswith('CAD'):
            [cate, frame_index] = frame_name.split('-')
            # load object detection result
            object_detection_result_path = self.data_path + \
                                           'CAD120_focusloss_detection'
            detected_object_name = os.path.join(object_detection_result_path,
                                                cate,
                                                '{}.json'.format(frame_index))
            if not os.path.exists(detected_object_name):
                self.no_detection_num += 1
                if self.epoch_index == 1:
                    self.f_statistics.write(
                        'No detected object: {}-{}\n'.format(cate, frame_index))
            else:
                with open(detected_object_name, 'r') as file:
                    detected_objects = json.load(file)
                filtered_objects = self.filter_objtect(detected_objects)
                # load image
                if self.is_visual_and_save:
                    image_raw_path = self.data_path + 'raw_image'
                    image_name = os.path.join(image_raw_path, cate,
                                              '{:04d}.png'.format(
                                                  int(frame_index)))
                    self.raw_image = cv2.imread(image_name)

                # load attention
                attention_path = self.data_path + 'attention_annotation_name'
                attention_annotation_name = os.path.join(attention_path, cate,
                                                         'attention-{}.json'.format(
                                                             frame_index))
                with open(attention_annotation_name, 'r') as file:
                    attentions = json.load(file)
                att_num = len(attentions)
                assert att_num == 1 or att_num == 2

                # if no object after filtered
                obj_num = len(filtered_objects)
                if obj_num < 1:
                    self.no_detection_num += 1
                    if self.epoch_index == 1:
                        self.f_statistics.write(
                            'No detected object after filtered: {}-{}\n'.format(
                                cate, frame_index))
                else:
                    if att_num == 1:
                        is_correct, best_obj = self.is_correct_for_one_attention(
                            filtered_objects, heatmap, attentions)
                        if self.is_visual_and_save:
                            self.draw_attention_on_raw_image(attentions)
                            self.draw_object_on_raw_image(best_obj)
                    if att_num == 2:
                        is_correct, best_obj, second_obj = self.is_correct_for_two_attention(
                            filtered_objects, heatmap, attentions)
                        if self.is_visual_and_save:
                            self.draw_object_on_raw_image(best_obj)
                            self.draw_object_on_raw_image(second_obj)
                            self.draw_attention_on_raw_image(attentions)

        elif self.data_name.startswith('TIA'):
            [task, video_base_name, frame_index] = frame_name.split(
                '-')  # frame_index is from 0
            object_detection_result_path = '/data2/datasets/TIA/focusloss_detection'
            detected_object_name = os.path.join(object_detection_result_path,
                                                task, video_base_name,
                                                '{}.json'.format(frame_index))
            if not os.path.exists(detected_object_name):
                self.no_detection_num += 1
                if self.epoch_index == 1:
                    self.f_statistics.write(
                        'No detected object: {}-{}-{}\n'.format(task,
                                                                video_base_name,
                                                                frame_index))
            else:
                with open(detected_object_name, 'r') as file:
                    detected_objects = json.load(file)
                filtered_objects = self.filter_objtect(
                    detected_objects)
                # load image
                if self.is_visual_and_save:
                    image_raw_path = '/data2/datasets/TIA_backup/raw_image'
                    image_names = sorted(os.listdir(
                        os.path.join(image_raw_path, task, video_base_name)))
                    image_name = os.path.join(image_raw_path, task,
                                              video_base_name,
                                              image_names[int(frame_index)])
                    self.raw_image = cv2.imread(image_name)

                # load attention
                attention_path = '/data2/datasets/TIA/attention_annotation_name'
                attention_annotation_name = os.path.join(attention_path, task,
                                                         video_base_name,
                                                         'AttentionBoxes_{}.json'.format(
                                                             frame_index))
                with open(attention_annotation_name, 'r') as file:
                    attentions = json.load(file)
                att_num = len(attentions)
                assert att_num == 1 or att_num == 2

                # if no object after filtered
                obj_num = len(filtered_objects)
                if obj_num < 1:
                    self.no_detection_num += 1
                    if self.epoch_index == 1:
                        self.f_statistics.write(
                            'No detected object after filtered: {}-{}-{}\n'.format(
                                task, video_base_name, frame_index))
                else:
                    if att_num == 1:
                        is_correct, best_obj = self.is_correct_for_one_attention(
                            filtered_objects, heatmap, attentions)
                        if self.is_visual_and_save:
                            self.draw_attention_on_raw_image(attentions)
                            self.draw_object_on_raw_image(best_obj)
                    if att_num == 2:
                        is_correct, best_obj, second_obj = self.is_correct_for_two_attention(
                            filtered_objects, heatmap, attentions)
                        if self.is_visual_and_save:
                            self.draw_object_on_raw_image(best_obj)
                            self.draw_object_on_raw_image(second_obj)
                            self.draw_attention_on_raw_image(attentions)

        if self.is_visual_and_save:
            cv2.imshow('1', self.raw_image)
            cv2.waitKey(10)
        return is_correct

    def draw_object_on_raw_image(self, best_obj, thickness=8):
        [obj_x1, obj_y1, obj_x2, obj_y2] = [
            int(best_obj[1] * self.W / self.image_size),
            int(best_obj[2] * self.H / self.image_size),
            int(best_obj[3] * self.W / self.image_size),
            int(best_obj[4] * self.H / self.image_size)]
        cv2.rectangle(self.raw_image, (obj_x1, obj_y1), (obj_x2, obj_y2),
                      (255, 0, 0), thickness=thickness)

    def draw_attention_on_raw_image(self, attentions, thickness=8):
        for attention in attentions:
            [att_name, att_x1, att_y1, att_x2, att_y2] = attention
            cv2.rectangle(self.raw_image, (att_x1, att_y1), (att_x2, att_y2),
                          (0, 0, 255), thickness=thickness)

    def is_correct_for_two_attention(self, filtered_objects, heatmap,
                                     attentions):
        best_obj, second_obj = self.find_best_two_objects(filtered_objects,
                                                          heatmap)
        flag = 0
        is_correct = False
        for attention in attentions:
            [att_name, att_x1, att_y1, att_x2, att_y2] = attention
            att_resize = [att_x1 * self.image_size / self.W,
                          att_y1 * self.image_size / self.H,
                          att_x2 * self.image_size / self.W,
                          att_y2 * self.image_size / self.H]
            iou1 = IOU_compute(att_resize, best_obj[1:])
            iou2 = IOU_compute(att_resize, second_obj[1:])
            if iou1 > 0.5 or iou2 > 0.5:
                flag += 1
        if flag == 2:
            is_correct = True
        return is_correct, best_obj, second_obj

    def is_correct_for_one_attention(self, filtered_objects, heatmap,
                                     attentions):
        is_correct = False
        [att_name, att_x1, att_y1, att_x2, att_y2] = attentions[0]
        att_resize = [att_x1 * self.image_size / self.W,
                      att_y1 * self.image_size / self.H,
                      att_x2 * self.image_size / self.W,
                      att_y2 * self.image_size / self.H]

        best_obj = self.find_best_one_obj(filtered_objects, heatmap)
        iou = IOU_compute(att_resize, best_obj[1:])
        if iou > 0.5:
            is_correct = True
        return is_correct, best_obj

    def filter_objtect(self, detected_objects):
        # filter_objects
        filtered_objects = []
        for obj in detected_objects:
            [name, x1, y1, x2, y2, prob] = obj
            if prob > self.focus_loss_IOU_threshold:
                filtered_objects.append(obj)
        return filtered_objects

    def find_best_one_obj(self, detected_objects, heatmap):
        assert len(detected_objects) > 0
        scored_objects = []
        for object in detected_objects:
            [name, x1, y1, x2, y2] = object[:5]
            x1 = int(x1 * self.image_size / self.W)
            x2 = int(x2 * self.image_size / self.W)
            y1 = int(y1 * self.image_size / self.H)
            y2 = int(y2 * self.image_size / self.H)
            s = abs(x1 - x2) * abs(y1 - y2)
            if s == 0:
                continue
            inside = heatmap[0, min(y1, y2):max(y1, y2),
                     min(x1, x2):max(x1, x2)]
            score = torch.sum(inside) / s
            scored_objects.append([score, x1, y1, x2, y2, name])

        assert len(scored_objects) > 0
        # find the best one
        max_socre = 0
        best_object = ['none', 224, 224, 224, 224, 'none']
        for elem in scored_objects:
            score = elem[0]
            if score > max_socre:
                best_object = elem
                max_socre = score

        return best_object

    def find_best_two_objects(self, detected_objects, heatmap):
        assert len(detected_objects) > 1
        scored_objects = []
        for object in detected_objects:
            [name, x1, y1, x2, y2, prob] = object
            x1 = int(x1 * self.image_size / self.W)
            x2 = int(x2 * self.image_size / self.W)
            y1 = int(y1 * self.image_size / self.H)
            y2 = int(y2 * self.image_size / self.H)
            s = abs(x1 - x2) * abs(y1 - y2)
            if s == 0:
                continue
            inside = heatmap[0, min(y1, y2):max(y1, y2),
                     min(x1, x2):max(x1, x2)]
            score = torch.sum(inside) / s
            # score.append(torch.sum(inside) / s)
            scored_objects.append([score, x1, y1, x2, y2])

        # find the best one
        max_socre = 0
        best_object = None
        second_object = None
        for elem in scored_objects:
            [score, x1, y1, x2, y2] = elem
            if score > max_socre:
                best_object = elem
                max_socre = score

        max_socre = 0
        for elem in scored_objects:
            if elem != best_object:
                [score, x1, y1, x2, y2] = elem
                if score > max_socre:
                    second_object = elem
                    max_socre = score

        return best_object, second_object

    def is_correct_using_annotated_objects(self, frame_name, heatmap):
        is_correct = False
        assert heatmap.size()[0] == 1
        objects, att_num = self.find_objects_use_frame_name(frame_name)
        score = []
        for object in objects:
            x1 = int(object[0]) * self.image_size / self.W
            y1 = int(object[1]) * self.image_size / self.H
            x2 = int(object[2]) * self.image_size / self.W
            y2 = int(object[3]) * self.image_size / self.H
            x1 = int(x1)
            x2 = int(x2)
            y1 = int(y1)
            y2 = int(y2)
            s = abs(x1 - x2) * abs(y1 - y2)
            if s == 0:
                continue
            inside = heatmap[0, min(y1, y2):max(y1, y2),
                     min(x1, x2):max(x1, x2)]
            score.append(torch.sum(inside) / s)
        index = score.index(max(score))
        att_num = int(att_num)
        assert att_num == 1 or att_num == 2, '{}'.format(frame_name)
        if att_num == 1:
            if index == 0:
                is_correct = True
        if att_num == 2:
            if index == 0 or index == 1:
                is_correct = True

        return is_correct

    def find_objects_use_frame_name(self, frame_name):
        if self.data_name.startswith('CAD'):
            [cate, frame_index] = frame_name.split('-')
            path = os.path.join('/data2/datasets', 'CAD120_backup',
                                'cad_where_are_they_02')
            self.txt_name = os.path.join(path, cate,
                                         'attention_objects_{}.txt'.format(
                                             frame_index))
        elif self.data_name.startswith('TIA'):
            [cate, video_base_name, frame_index] = frame_name.split(
                '-')  # frame_index is from 0
            frame_index = int(frame_index)
            path = '/data2/datasets/TIA_backup/TIA_where_are_they_nms'
            txt_name = "attention_objects_{:04d}.txt".format(frame_index)
            self.txt_name = os.path.join(path, cate, video_base_name, txt_name)

        objects = []
        with open(self.txt_name, 'r') as f:
            line = f.readline().strip().split(' ')
            new_line = line[2:]
            att_num = line[0]
            obj_num = line[1]
            all_num = len(new_line) / 4
            for i in range(int(all_num)):
                each_object = [new_line[i * 4], new_line[i * 4 + 1],
                               new_line[i * 4 + 2], new_line[i * 4 + 3]]
                objects.append(each_object)
        return objects, att_num


def main():
    xx = Test()


if __name__ == '__main__':
    main()