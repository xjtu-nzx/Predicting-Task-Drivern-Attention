class NetworksFactory:
    def __init__(self):
        pass

    @staticmethod
    def get_by_name(network_name, *args, **kwargs):
        if network_name == 'encoder_decoder_lstm':
            from networks.encoder_decoder_lstm import AttentionPrediction
            network = AttentionPrediction(*args, **kwargs)        
        elif network_name == 'human_attention_new':
            from networks.human_attention import AttentionPrediction
            network = AttentionPrediction()
        else:
            raise ValueError("Network %s not recognized." % network_name)

        print("Network %s was created" % network_name)

        return network
