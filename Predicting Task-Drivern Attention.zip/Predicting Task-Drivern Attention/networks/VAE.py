import torch.nn as nn
import torch
import torch.nn.functional as F


# VAE is to add prior


class VAE(nn.Module):
    def __init__(self):
        super(VAE, self).__init__()
        LATENT_CODE_NUM = 20

        self.encoder = nn.Sequential(
            nn.Conv2d(1, 64, kernel_size=4, stride=2, padding=1),
            nn.BatchNorm2d(64),
            nn.LeakyReLU(0.2, inplace=True),

            nn.Conv2d(64, 128, kernel_size=4, stride=2, padding=1),
            nn.BatchNorm2d(128),
            nn.LeakyReLU(0.2, inplace=True),

            nn.Conv2d(128, 128, kernel_size=3, stride=1, padding=1),
            nn.BatchNorm2d(128),
            nn.LeakyReLU(0.2, inplace=True),
        )

        self.fc11 = nn.Linear(128 * 7 * 7, LATENT_CODE_NUM)

        self.fc12 = nn.Linear(128 * 7 * 7, LATENT_CODE_NUM)
        self.fc2 = nn.Linear(LATENT_CODE_NUM, 128 * 7 * 7)

        self.decoder = nn.Sequential(
            nn.ConvTranspose2d(128, 64, kernel_size=4, stride=2, padding=1),
            nn.ReLU(inplace=True),

            nn.ConvTranspose2d(64, 1, kernel_size=4, stride=2, padding=1),
            nn.Sigmoid()
        )

    # In order to deal with the fact that the network may learn negative values
    # ,we'll typically have the network learn and exponentiate this value to
    # get the latent distribution's variance.
    def reparameterize(self, mu, logvar):
        eps = torch.randn(mu.size(0), mu.size(
            1)).cuda()
        # torch.randn, sample randomly from standard normal distribution
        z = mu + eps * torch.exp(logvar / 2)

        return z

    def forward(self, x):
        out1, out2 = self.encoder(x), self.encoder(x)  # batch_s, 8, 7, 7
        mu = self.fc11(out1.view(out1.size(0), -1))  # batch_s, latent
        logvar = self.fc12(out2.view(out2.size(0), -1))  # batch_s, latent
        z = self.reparameterize(mu, logvar)  # batch_s, latent
        out3 = self.fc2(z).view(z.size(0), 128, 7, 7)  # batch_s, 8, 7, 7
        return self.decoder(out3), mu, logvar


class VAE_Official(nn.Module):
    def __init__(self, input_size=784, h_dim=400, z_dim=20):
        super(VAE_Official, self).__init__()
        self.fc1 = nn.Linear(input_size, h_dim)
        self.fc2 = nn.Linear(h_dim, z_dim)  # ?? ??
        self.fc3 = nn.Linear(h_dim, z_dim)  # ???? ??
        self.fc4 = nn.Linear(z_dim, h_dim)
        self.fc5 = nn.Linear(h_dim, input_size)

    # ????
    def encode(self, x):
        h = F.relu(self.fc1(x))
        return self.fc2(h), self.fc3(h)

    # ????????
    def reparameterize(self, mu, log_var):
        std = torch.exp(log_var / 2)
        eps = torch.randn_like(std)
        return mu + eps * std

    # ????
    def decode(self, z):
        h = F.relu(self.fc4(z))
        return torch.sigmoid(self.fc5(h))

    # ???????????-???
    def forward(self, x):
        mu, log_var = self.encode(x)
        z = self.reparameterize(mu, log_var)
        x_reconst = self.decode(z)

        return x_reconst, mu, log_var


def vae_loss(x, x_reconst, mu, log_var):
    xent_loss = F.binary_cross_entropy(x_reconst, x, size_average=False)
    kl_div_loss = - 0.5 * torch.sum(1 + log_var - mu.pow(2) - log_var.exp())

    return xent_loss + kl_div_loss


class MultiModalVAE(nn.Module):
    def __init__(self):
        super(MultiModalVAE, self).__init__()

    def forward(self, *input):
        pass

