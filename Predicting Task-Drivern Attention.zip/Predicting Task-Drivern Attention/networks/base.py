import torch.nn as nn
import functools
import torch
import math
import torch.nn.functional as F


class NetworkBase(nn.Module):
    def __init__(self):
        super(NetworkBase, self).__init__()
        self._name = 'BaseNetwork'

    @property
    def name(self):
        return self._name

    def init_weights(self):
        self.apply(self._weights_init_fn)

    def _weights_init_fn(self, m):
        classname = m.__class__.__name__

        if classname.find('Conv') != -1 and classname.find('ConvLSTM') == -1:
            if m.weight.requires_grad:
                pass
            else:
                m.weight.data.normal_(0.0, 0.02)
                if hasattr(m.bias, 'data'):
                    m.bias.data.fill_(0)
        elif classname.find('BatchNorm2d') != -1:
            m.weight.data.normal_(1.0, 0.02)
            m.bias.data.fill_(0)

    def _get_norm_layer(self, norm_type='batch'):
        if norm_type == 'batch':
            norm_layer = functools.partial(nn.BatchNorm2d,
                                           affine=True)  # looks appealing
        elif norm_type == 'instance':
            norm_layer = functools.partial(nn.InstanceNorm2d, affine=False)
        elif norm_type == 'batchnorm2d':
            norm_layer = nn.BatchNorm2d
        else:
            raise NotImplementedError(
                'normalization layer [%s] is not found' % norm_type)

        return norm_layer


class DeConvNetwork(NetworkBase):
    def __init__(self, input_dim=None):
        super(DeConvNetwork, self).__init__()
        self.relu = nn.LeakyReLU(inplace=True)
        self.sigmoid = nn.Sigmoid()

        self.deconv1 = nn.ConvTranspose2d(input_dim, 512, kernel_size=4,
                                          stride=2, padding=1, bias=False)
        self.deconv1_bn = torch.nn.BatchNorm2d(512)

        self.deconv2 = nn.ConvTranspose2d(512, 256, kernel_size=4, stride=2,
                                          padding=1, bias=False)
        self.deconv2_bn = torch.nn.BatchNorm2d(256)

        self.deconv3 = nn.ConvTranspose2d(256, 256, kernel_size=4, stride=2,
                                          padding=1, bias=False)
        self.deconv3_bn = torch.nn.BatchNorm2d(256)

        self.deconv4 = nn.ConvTranspose2d(256, 128, kernel_size=4, stride=2,
                                          padding=1, bias=False)
        self.deconv4_bn = torch.nn.BatchNorm2d(128)

        self.deconv5 = nn.ConvTranspose2d(128, 64, kernel_size=4, stride=2,
                                          padding=1, bias=False)
        self.deconv5_bn = torch.nn.BatchNorm2d(64)

        self.conv6 = nn.Conv2d(64, 1, kernel_size=3, stride=1, padding=1,
                               bias=False)

    def forward(self, x):
        x = self.deconv1(x)
        x = self.deconv1_bn(x)
        x = self.relu(x)  # 512, 32

        x = self.deconv2(x)
        x = self.deconv2_bn(x)
        x = self.relu(x)  # 256, 64

        x = self.deconv3(x)
        x = self.deconv3_bn(x)
        x = self.relu(x)  # 128, 128

        x = self.deconv4(x)
        x = self.deconv4_bn(x)
        x = self.relu(x)  # 64, 256

        x = self.deconv5(x)
        x = self.deconv5_bn(x)
        x = self.relu(x)  # 64, 224,224

        x = self.conv6(x)
        out1 = self.sigmoid(x)  # 16,1,224,224

        return out1


class ResidualBlock(nn.Module):
    def __init__(self, ChannelNum=512):
        super(ResidualBlock, self).__init__()
        self.residual_cnn = nn.Sequential(
            nn.Conv2d(ChannelNum, ChannelNum, kernel_size=1, stride=1,
                      padding=0),
            nn.BatchNorm2d(ChannelNum),
            nn.ReLU(inplace=True),
            nn.Conv2d(ChannelNum, ChannelNum, kernel_size=1, stride=1,
                      padding=0),
            nn.BatchNorm2d(ChannelNum))

    def forward(self, x):
        residual = x
        out = self.residual_cnn(x)
        out += residual
        return out


class FullyConnectCls(nn.Module):
    def __init__(self, InputDim=512, OutputDim=10):
        super(FullyConnectCls, self).__init__()
        self.classification = nn.Sequential(
            nn.Linear(InputDim, 4096),
            nn.Dropout(),
            nn.Linear(4096, 4096),
            nn.Dropout(),
            nn.Linear(4096, OutputDim))

    def forward(self, x):
        x = self.classification(x)
        return x


# Channel Attention (CA) Layer
class CALayer(nn.Module):
    def __init__(self, channel, reduction=8):
        super(CALayer, self).__init__()
        # global average pooling: feature --> point
        self.avg_pool = nn.AdaptiveAvgPool2d(1)
        # feature channel downscale and upscale --> channel weight
        self.conv_du = nn.Sequential(
                nn.Conv2d(channel, channel // reduction, 1,
                          padding=0, bias=True),
                nn.ReLU(inplace=True),
                nn.Conv2d(channel // reduction, channel, 1,
                          padding=0, bias=True),
                nn.Sigmoid()
        )

    def forward(self, x, y):
        y = self.avg_pool(y)
        y = self.conv_du(y)
        return x * y


# scaled dot-production attention
def dot_attention(query, key, value, mask=None, dropout=None):
    """ usually query and value is same.
    """
    d_k = query.size(-1)
    score = torch.matmul(query, key.transpose(-2, -1)) / math.sqrt(d_k)
    if mask is not None:
        score = score.masked_fill(mask == 0, -1e9)
    p_attn = F.softmax(score, dim=-1)
    if dropout is not None:
        p_attn = dropout(p_attn)
    return torch.matmul(p_attn, value)


class SelfAttn(nn.Module):
    """CNN-based Self attention Layer"""
    def __init__(self, in_dim, activation=None):
        super(SelfAttn, self).__init__()
        self.chanel_in = in_dim
        self.activation = activation

        self.query_conv = nn.Conv2d(in_channels=in_dim,
                                    out_channels=in_dim // 8, kernel_size=1)
        self.key_conv = nn.Conv2d(in_channels=in_dim, out_channels=in_dim // 8,
                                  kernel_size=1)
        self.value_conv = nn.Conv2d(in_channels=in_dim, out_channels=in_dim,
                                    kernel_size=1)
        self.gamma = nn.Parameter(torch.zeros(1))

        self.softmax = nn.Softmax(dim=-1)  #

    def forward(self, x):
        """
            x : input feature maps( B X C X W X H)
            returns :
            self attention value + input feature
            attention: B X N X N (N is Width*Height)
        """
        bs, C, width, height = x.size()
        proj_query = self.query_conv(x).view(bs, -1, width * height
                                             ).permute(0, 2, 1)  # B X CX(N)
        proj_key = self.key_conv(x).view(bs, -1,
                                         width * height)  # B X C x (*W*H)
        energy = torch.bmm(proj_query, proj_key)  # transpose check
        attention = self.softmax(energy)  # BX (N) X (N)
        proj_value = self.value_conv(x).view(bs, -1,
                                             width * height)  # B X C X N

        out = torch.bmm(proj_value, attention.permute(0, 2, 1))
        out = out.view(bs, C, width, height)

        out = self.gamma * out + x

        return out, attention
