import torch
import torch.nn as nn
import torch.nn.functional as F

from networks.ResNet import resnet50, resnet18, resnet34
from networks.VGG import vgg16, vgg19
from networks.base import NetworkBase, DeConvNetwork, SelfAttn
from networks.task_encoding import TaskModule, TaskEmbedding
from networks.convlstm import ConvLSTM
from networks.convgru1 import ConvGRU

from options.train_opt import TrainOptions


class AttentionPrediction(NetworkBase):
    """Attention_model. """
    def __init__(self):
        super(AttentionPrediction, self).__init__()
        self.opt = TrainOptions().parse()

        self.hidden_dim = 512
        self.hidden_feature_dim = 7

        self.fusion_cat = 1
        self.fusion_add = 0
        self.motion_flag = 1
        self.hsi_flag = 1
        self.only_image_flag = 0
        self.gpu_num = len(self.opt.gpu_ids)

        # feature extraction
        if self.opt.backbone == 'resnet18':
            self.resnet_1channel = resnet18(pretrained=True, channel=1)
            self.resnet_2channel = resnet18(pretrained=True, channel=2)
            self.resnet_3channel = resnet18(pretrained=True, channel=3)
        elif self.opt.backbone == 'resnet34':
            self.resnet_1channel = resnet34(pretrained=True, channel=1)
            self.resnet_2channel = resnet34(pretrained=True, channel=2)
            self.resnet_3channel = resnet34(pretrained=True, channel=3)
        elif self.opt.backbone == 'resnet50':
            self.resnet_1channel = resnet50(pretrained=True, channel=1)
            self.resnet_2channel = resnet50(pretrained=True, channel=2)
            self.resnet_3channel = resnet50(pretrained=True, channel=3)
        elif self.opt.backbone == 'vgg16':
            self.resnet_1channel = vgg16(pretrained=True, channel=1)
            self.resnet_2channel = vgg16(pretrained=True, channel=2)
            self.resnet_3channel = vgg16(pretrained=True, channel=3)
        elif self.opt.backbone == 'vgg19':
            self.resnet_1channel = vgg19(pretrained=True, channel=1)
            self.resnet_2channel = vgg19(pretrained=True, channel=2)
            self.resnet_3channel = vgg19(pretrained=True, channel=3)
        else:
            raise ModuleNotFoundError

        # human-scene attention
        self.hs_att_1 = SelfAttn(in_dim=512)
        self.hs_att_2 = SelfAttn(in_dim=512)
        self.Cnn_Unit = nn.Sequential(
                                      nn.BatchNorm2d(self.hidden_dim),
                                      nn.ReLU())

        self.motion_attn = SelfAttn(in_dim=512)

        # task encoding and classification
        if self.opt.TaskNetwork:
            if self.opt.use_embed:
                self.task_module = TaskEmbedding(in_channels=self.hidden_dim,
                                                 # task_num=self.opt.task_num
                                                 task_num=self.opt.action_num * self.opt.task_num
                                                 )
            else:
                self.task_module = TaskModule(in_channels=self.hidden_dim,
                                              task_num=self.opt.task_num)

        if self.opt.temp_mode == 'Conv3D':
            self.temp_encoding = nn.Sequential(
                nn.Conv3d(in_channels=self.hidden_dim,
                          out_channels=self.hidden_dim,
                          kernel_size=3,
                          padding=1))
        elif self.opt.temp_mode == 'ConvLSTM':
            self.temp_encoding = ConvLSTM(input_dim=512,
                                          hidden_dim=[256, 512],
                                          kernel_size=(3, 3),
                                          num_layers=2,
                                          batch_first=True,
                                          bias=True,
                                          return_all_layers=False,
                                          )
        elif self.opt.temp_mode == 'ConvGRU':
            self.temp_encoding = ConvGRU(input_dim=512,
                                         hidden_dim=[256, 512],
                                         kernel_size=(3, 3),
                                         num_layers=2,
                                         batch_first=True,
                                         bias=True,
                                         return_all_layers=False)
        else:
            raise ModuleNotFoundError

        # upsample
        self.decoder = DeConvNetwork(input_dim=self.hidden_dim)

    def forward(self, x_list, action_embeds_list, task_embeds_list):
        # x_list is the "input['concat_feature_numpy']"
        # x_list: temporal_step: [bs, channel, 224, 224]
        result = {'task_predict': None,
                  'task_encoder': None,
                  'task_decoder': None,
                  'att_map': None,
                  'vae_loss': None,
                  'vae_distance': None,
                  }
        attention_map = []
        task_prediction = []
        vea_losses = []
        # vae_cosin = []
        self.conv3d_feature = torch.zeros(self.opt.temporal_state,
                                          self.opt.batch_size // self.gpu_num,
                                          self.hidden_dim,
                                          self.hidden_feature_dim,
                                          self.hidden_feature_dim
                                          ).cuda()

        img = []
        pose = []
        motion = []
        for i, x in enumerate(x_list):
            # encoder for input [~, 512, 7, 7]
            scene_init_fm = self.resnet_3channel.fm_extract(x[:, :3, :, :])
            human_init_fm = self.resnet_1channel.fm_extract(x[:, 3:4, :, :])
            motion_init_fm = self.resnet_2channel.fm_extract(x[:, 4:6, :, :])

            if self.hsi_flag:
                s2h_att, _ = self.hs_att_2(scene_init_fm)
				s2h_att = self.Cnn_Unit(s2h_att)
                img.append(s2h_att.mean(1).detach())
 
                h2s_att, _ = self.hs_att_1(human_init_fm)
				h2s_att = self.Cnn_Unit(h2s_att)
                pose.append(h2s_att.mean(1).detach())


                #human_scene_fm = torch.cat((h2s_att, s2h_att), dim=1)
                # (batch, 512, 7, 7)
                #human_scene_fm = self.Cnn_Unit(human_scene_fm)

            # add motion
            if self.motion_flag:
                motion_init_fm, _ = self.motion_attn(motion_init_fm)
				motion_init_fm = self.Cnn_Unit(motion_init_fm)
                motion.append(motion_init_fm.mean(1).detach())             
                bottom_up_fm = h2s_att + s2h_att + motion_init_fm     

            # task module: classification
            if self.opt.TaskNetwork:
                if self.opt.use_embed:
                    embeds = torch.cat([action_embeds_list[i],
                                        task_embeds_list[i]], dim=-2)
                    task_fm, task_pre, loss_vae = \
                        self.task_module(bottom_up_fm, embeds)
                else:
                    task_fm, task_pre, loss_vae = self.task_module(bottom_up_fm)

                task_prediction.append(task_pre)
                vea_losses.append(loss_vae)

            # Conv3D Input
            self.conv3d_feature[i, :, :, :, :] = task_fm  # [bs, 512, 7, 7]

        result["img"] = img
        result["pose"] = pose
        result["motion"] = motion
        result['task_predict'] = task_prediction
        result['vae_loss'] = vea_losses
        # result['vae_distance'] = vae_cosin

        del task_prediction, vea_losses

        # global operate
        if self.opt.temp_mode == 'Conv3D':
            self.conv3d_feature = self.conv3d_feature.transpose(0, 1).transpose(
                1, 2)  # [bs, 512, T, 7, 7]
            self.conv3d_feature = self.temp_encoding(self.conv3d_feature)
            self.conv3d_feature = self.conv3d_feature.transpose(1, 2).transpose(
                1, 0)  # [T, bs, 512, 7, 7]
        else:
            self.conv3d_feature = self.temp_encoding(
                self.conv3d_feature.transpose(0, 1))[0][0].transpose(0, 1)

        # decoder
        for i in range(self.opt.temporal_state):
            attention_map.append(self.decoder(self.conv3d_feature[i]))

        result['att_map'] = attention_map
        del attention_map, self.conv3d_feature

        return result



if __name__ == '__main__':
    model = AttentionPrediction()

    img_list = []
    for i in range(5):
        img = torch.randn(1, 3, 224, 224)
        img_list.append(img)
    network = model.to(torch.device('cuda:0'))
    img_list = img_list.to(torch.device('cuda:0'))
    # img_list = torch.randn(16, 10, 2048, 7, 7)
    out = network(img_list)

    # pass
    a = {"1": 1}
    b = {"2": 2}
    print(dict(a, **b))

