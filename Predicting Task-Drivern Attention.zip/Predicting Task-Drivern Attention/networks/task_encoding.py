import torch
import torch.nn as nn
from networks.VAE import VAE_Official
from loss.loss import vae_loss


class TaskModule(nn.Module):
    def __init__(self, in_channels, task_num):
        """ Task Classification
        :param in_channels: input map of encoder
        :param task_num:
        """
        super(TaskModule, self).__init__()
        self.task_cnn_3_kernel = nn.Sequential(
                                        nn.Conv2d(in_channels=in_channels,
                                                  out_channels=in_channels,
                                                  kernel_size=3,
                                                  padding=1),
                                        nn.BatchNorm2d(in_channels), nn.ReLU())
        self.task_cnn_1_kernel = nn.Sequential(
                                        nn.Conv2d(in_channels=in_channels,
                                                  out_channels=in_channels,
                                                  kernel_size=1,
                                                  padding=0),
                                        nn.BatchNorm2d(in_channels), nn.ReLU())
        self.ave_pool = nn.AvgPool2d(kernel_size=7)

        self.vae = VAE_Official(input_size=512, h_dim=400, z_dim=20)

        self.task_classifier = nn.Sequential(nn.Linear(512, 512),
                                             nn.ReLU(True),
                                             nn.Dropout(),
                                             nn.Linear(512, 256),
                                             nn.ReLU(True),
                                             nn.Dropout(),
                                             nn.Linear(256, task_num),
                                             )

    def forward(self, fm):  # input (bs, 512, 7, 7)
        task_fm_01 = self.task_cnn_3_kernel(fm)
        task_fm_01 = self.task_cnn_3_kernel(task_fm_01)
        task_fm_02 = fm + task_fm_01
        task_fm_02 = self.task_cnn_1_kernel(task_fm_02)

        x = self.ave_pool(task_fm_02)  # [batch, 512, 1, 1]
        x_reconst, mu, log_var = self.vae(x.view(x.size(0), -1))  # [batch, 512]
        loss_vae = vae_loss(x.squeeze(), x_reconst.squeeze(), mu, log_var)

        task_predict = self.task_classifier(
            x_reconst.view(x_reconst.size(0), -1))  # [batch, n_task]

        return task_fm_02, task_predict, loss_vae


class TaskEmbedding(nn.Module):
    def __init__(self, in_channels, task_num):
        """ Task Classification
        :param in_channels: input map of encoder
        :param task_num:
        """
        super(TaskEmbedding, self).__init__()
        self.task_cnn_3_kernel = nn.Sequential(
                                        nn.Conv2d(in_channels=in_channels,
                                                  out_channels=in_channels,
                                                  kernel_size=3,
                                                  padding=1),
                                        nn.BatchNorm2d(in_channels),
                                        nn.ReLU())
        self.task_cnn_1_kernel = nn.Sequential(
                                        nn.Conv2d(in_channels=in_channels,
                                                  out_channels=in_channels,
                                                  kernel_size=1,
                                                  padding=0),
                                        nn.BatchNorm2d(in_channels),
                                        nn.ReLU())
        self.ave_pool = nn.AvgPool2d(kernel_size=7)

        self.vae = VAE_Official(input_size=512, h_dim=400, z_dim=20)

        self.task_embedding = nn.Sequential(nn.Dropout(),
                                            nn.Linear(768, 512),
                                            nn.ReLU(True))
        self.combined_embedding = nn.Sequential(nn.Linear(1024, 512),
                                                nn.ReLU(True),
                                                nn.Dropout())
        # task classification
        self.task_classifier = nn.Sequential(nn.Linear(512, 512),
                                             nn.ReLU(True),
                                             nn.Dropout(),
                                             nn.Linear(512, 256),
                                             nn.ReLU(True),
                                             nn.Dropout(),
                                             nn.Linear(256, task_num),
                                             )

    def forward(self, fm, embed):  # input (bs, 512, 7, 7)
        task_fm_01 = self.task_cnn_3_kernel(fm)
        task_fm_01 = self.task_cnn_3_kernel(task_fm_01)
        task_fm_01 = fm + task_fm_01
        task_fm_01 = self.task_cnn_1_kernel(task_fm_01)  # [bs, 512, 7, 7]

        x = self.ave_pool(task_fm_01)

        embed = self.task_embedding(
            embed.view(-1, 768)
        ).view(x.size(0), 2, -1).mean(dim=1)

        x = self.combined_embedding(
            torch.cat([x.view(x.size(0), -1), embed], dim=1))

        x_reconst, mu, log_var = self.vae(x)  # [batch, 512]
        loss_vae = vae_loss(x.squeeze(), x_reconst.squeeze(), mu, log_var)

        task_predict = self.task_classifier(
            x_reconst.view(x_reconst.size(0), -1))  # [bs, n_task]

        return task_fm_01, task_predict, loss_vae


