from torch import nn
import torch.nn.functional as F
import torch
import numpy as np
from options.train_opt import TrainOptions
from torch.nn.functional import binary_cross_entropy, \
    binary_cross_entropy_with_logits, cross_entropy


# loss function: seven probability map --- 6 scale + 1 fuse
class Loss(nn.Module):
    def __init__(self, weight=[1.0] * 7):
        super(Loss, self).__init__()
        self.weight = weight

    def forward(self, x_list, label):
        loss = self.weight[0] * F.binary_cross_entropy(x_list[0], label)
        for i, x in enumerate(x_list[1:]):
            loss += self.weight[i + 1] * F.binary_cross_entropy(x, label)
        return loss


def MseLoss(prediction, gt):
    loss = nn.MSELoss().cuda()
    return loss(prediction, gt)


def CrossEntropyLoss(prediction, gt):
    loss = nn.CrossEntropyLoss(reduction='mean').cuda()
    return loss(prediction, gt)


def outside_loss(gt_map_batch, pre_map_batch):
    # heat_outside = 0
    # gt_map_batch = gt_map_batch.squeeze()
    # pre_map_batch = pre_map_batch.squeeze()
    # from (batch, 1, 224, 224) to (batch, 224, 224)
    # for i in range(batch_size):
    common_outside = pre_map_batch * (1.0 - gt_map_batch)
    heat_outside = common_outside.sum() / (1.0 - gt_map_batch).sum()
    return heat_outside


def inside_loss(gt_map_batch, pre_map_batch):
    # heat_outside = 0
    # gt_map_batch = gt_map_batch.squeeze()
    # pre_map_batch = pre_map_batch.squeeze()
    # from (batch, 1, 224, 224) to (batch, 224, 224)
    # for i in range(batch_size):
    # common_outside = pre_map_batch * (1.0 - gt_map_batch)
    common_inside = pre_map_batch * gt_map_batch
    # heat_outside = common_outside.sum() / (1.0 - gt_map_batch).sum()
    heat_inside = common_inside.sum() / gt_map_batch.sum
    return heat_inside


def weight_CELoss_batch(gt_map_batch, pre_map_batch):
    # gt_map_batch = gt_map_batch.squeeze()
    # pre_map_batch = pre_map_batch.squeeze()
    # from (batch, 1, 224, 224) to (batch, 224, 224)
    # loss = 0
    # for i in range(batch_size):
    attention_area = gt_map_batch.sum()
    weight = attention_area / (224 * 224)
    pre_map_batch = pre_map_batch.clamp(min=0.01, max=0.99)
    weight_loss = (1 - weight) * gt_map_batch * pre_map_batch.log() + weight * (
                1 - gt_map_batch) * (1 - pre_map_batch).log()
    loss = weight_loss.sum()
    return -loss


def weight_CELoss_Mean(gt_map_batch, pre_map_batch):
    assert gt_map_batch.size() == pre_map_batch.size()

    dim = list(gt_map_batch.size())
    dim_num = len(dim)
    pixel_num = 1
    for i in range(dim_num):
        pixel_num *= dim[i]

    attention_area = gt_map_batch.sum()
    weight = attention_area / pixel_num

    pre_map_batch = pre_map_batch.clamp(min=0.01, max=0.99)
    weight_loss = (1 - weight) * gt_map_batch * pre_map_batch.log() + weight * (
                1 - gt_map_batch) * (1 - pre_map_batch).log()

    # loss = weight_loss.sum()
    loss = weight_loss.mean()

    return -loss


def weight_CELoss_Sum(gt_map_batch, pre_map_batch):
    assert gt_map_batch.size() == pre_map_batch.size()

    dim = list(gt_map_batch.size())
    dim_num = len(dim)
    pixel_num = 1
    for i in range(dim_num):
        pixel_num *= dim[i]

    attention_area = gt_map_batch.sum()
    weight = attention_area / pixel_num

    pre_map_batch = pre_map_batch.clamp(min=0.01, max=0.99)
    weight_loss = (1 - weight) * gt_map_batch * pre_map_batch.log() + weight * (
                1 - gt_map_batch) * (1 - pre_map_batch).log()

    loss = weight_loss.sum()
    # loss = weight_loss.mean()

    return -loss


def vae_loss(x, x_reconst, mu, log_var):
    dim = list(x.size())
    dim_num = len(dim)
    pixel_num = 1
    for i in range(dim_num):
        pixel_num *= dim[i]

    xent_loss = F.binary_cross_entropy(x_reconst.detach(), x.detach())
    kl_div_loss = - 0.5 * (1 + log_var - mu.pow(2) - log_var.exp())
    kl_div_loss = kl_div_loss.mean()
    xent_loss = xent_loss.mean()
    return xent_loss + kl_div_loss


def dice_coefficient_loss(gt_tensor, pre_tensor):
    # dice = 2*(a and b)/(a or b)

    common = gt_tensor * pre_tensor
    gt_and_pre = common.sum()

    # gt_mask = gt_tensor>0
    square_gt = gt_tensor * gt_tensor
    square_pre = pre_tensor * pre_tensor
    square_sum_gt = square_gt.sum()
    square_sum_pre = square_pre.sum()

    loss = gt_and_pre / (square_sum_gt + square_sum_pre)

    return 1 - 2 * loss


if __name__ == '__main__':
    # a = np.random.random((3,4))
    # b = torch.from_numpy(a).float().cuda()

    a = np.zeros((3, 4))
    c = -torch.from_numpy(a)
    print(c.log())
    # print(torch.log(c))
    # print(weighted_cross_entropy_loss_for_heat_map(b,c))
