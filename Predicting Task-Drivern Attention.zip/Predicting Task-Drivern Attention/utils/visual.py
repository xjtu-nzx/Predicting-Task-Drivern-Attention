import random, colorsys, cv2


def random_colors(N, bright=True):
    """
    Generate random colors.
    To get visually distinct colors, generate them in HSV space then
    convert to RGB.
    """
    brightness = 1.0 if bright else 0.7   # 3元表达式
    hsv = [(i / N, 1, brightness) for i in range(N)]   #  H-  , S-饱和度(0-1), V-明度(0-1)
    colors = list(map(lambda c: colorsys.hsv_to_rgb(*c), hsv))   # lambda argument_list : function_expression
    random.shuffle(colors)
    # colors = [color*255 for color in colors]

    return colors

def draw_on_image(image = None):

    bbox = [1,2,3,4]
    text = 'text'
    color255 = (255,0,0)
    cv2.putText(image, str(text), ((int(float(bbox[1])), int(float(bbox[0]) - 5))), cv2.FONT_HERSHEY_SIMPLEX, 1, color255,
                thickness=2)

    b_lt = (int(float(bbox[1])), int(float(bbox[0])))
    b_rb = (int(float(bbox[3])), int(float(bbox[2])))
    cv2.rectangle(image, b_lt, b_rb, color255, 2)
    cv2.circle(image, center=(x,y), radius=2,color=(255,0,255),thickness=2,lineType=8)