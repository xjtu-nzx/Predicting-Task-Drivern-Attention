import matplotlib.pyplot as plt

x = [1,2,3,4,5]
y = [0.1, 0.2, 0.3, 0.4, 0.5]
y2 = [0.1, 0.2, 0.3, 0.4, 0.5]
plt.ion()
# plt.title('Training Loss Curve')
# plt.xlabel("Iters")
# plt.ylabel("Loss")

fig = plt.figure()
ax211 = fig.add_subplot(211)
ax211.set_title('Global Loss')
# ax211.set_xlabel('iters')
# ax211.set_ylabel('Loss')
ax212 = fig.add_subplot(212)
# ax212.hspace = 2
ax212.set_title('Local Loss')
plt.subplots_adjust(hspace=0.5, wspace=0)
# line1, = ax.plot(x, y, 'r-')
# plt.draw()

# for phase in np.linspace(0, 10*np.pi, 500):
#     line1.set_ydata(np.sin(x + phase))
#     plt.draw()
#     plt.pause(0.02)

for i in range(50):

    print(i)
    x.append(i)
    y.append(i*0.1)
    y2.append(i * 0.3)
    #
    ax211.plot(x,y,'r-')
    ax212.plot(x,y2,'b-')
    # plt.plot(range(1, len(y)+1), y, label = 'local')
    # plt.plot(range(1, len(y)+1), y2, label='global')
    # plt.legend()
    # plt.draw()
    plt.pause(0.5)
    plt.show()
