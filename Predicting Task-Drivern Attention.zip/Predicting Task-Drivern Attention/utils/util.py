from __future__ import print_function
from PIL import Image
import numpy as np
import os
import torchvision
import math
import torch


def IOU_NMS_Objs_by_Att(obj_list,att_list, threshold):
    assert isinstance(obj_list,list)
    assert isinstance(att_list,list)

    filtered_objects = []
    org_box_num = int(len(obj_list))
    att_box_num = int(len(att_list))
    for j in range(org_box_num):
        [name, x1, y1, x2, y2] = obj_list[j]
        tem_obj = [int(x1), int(y1), int(x2), int(y2)]
        assert isinstance(tem_obj,list)
        is_attention = 0
        for i in range(att_box_num):
            [name, x1_a, y1_a, x2_a, y2_a] = att_list[i]
            tem_att = [int(x1_a), int(y1_a), int(x2_a), int(y2_a)]
            assert isinstance(tem_att,list)
            Iou = IOU_compute(tem_obj, tem_att)
            if Iou > threshold:
                is_attention=1
                break
        if is_attention ==0:
            filtered_objects.append(obj_list[j])

    return filtered_objects


def IOU_compute(boxA,boxB):
    # [x1,y1,x2,y2] = [bbox1[0],bbox1[1],bbox1[2],bbox1[3]]
    xA = max(boxA[0], boxB[0])
    yA = max(boxA[1], boxB[1])
    xB = min(boxA[2], boxB[2])
    yB = min(boxA[3], boxB[3])

    # compute the area of intersection rectangle
    interArea = max(0, xB - xA + 1) * max(0, yB - yA + 1)

    # compute the area of both the prediction and ground-truth
    # rectangles
    boxAArea = (boxA[2] - boxA[0] + 1) * (boxA[3] - boxA[1] + 1)
    boxBArea = (boxB[2] - boxB[0] + 1) * (boxB[3] - boxB[1] + 1)

    # compute the intersection over union by taking the intersection
    # area and dividing it by the sum of prediction + ground-truth
    # areas - the interesection area
    iou = interArea / float(boxAArea + boxBArea - interArea)

    # return the intersection over union value
    return iou


def tensor2im(img, imtype=np.uint8, unnormalize=False, idx=0, nrows=None):
    # select a sample or create grid if img is a batch
    if len(img.shape) == 4:
        nrows = nrows if nrows is not None else int(math.sqrt(img.size(0)))
        img = img[idx] if idx >= 0 else torchvision.utils.make_grid(img, nrows)

    img = img.cpu().float()

    if unnormalize:
        mean = [0.5, 0.5, 0.5]
        std = [0.5, 0.5, 0.5]

        for i, m, s in zip(img, mean, std):
            i.mul_(s).add_(m)

    image_numpy = img.numpy()
    image_numpy_t = np.transpose(image_numpy, (1, 2, 0))
    image_numpy_t = image_numpy_t*255.0

    if image_numpy_t.shape[-1] == 1:
        image_numpy_t = np.tile(image_numpy_t, (1,1,3))

    return image_numpy_t.astype(imtype)

def tensor2maskim(mask, imtype=np.uint8, idx=0, nrows=1):
    im = tensor2im(mask, imtype=imtype, idx=idx, unnormalize=False, nrows=nrows)
    if im.shape[2] == 1:
        im = np.repeat(im, 3, axis=-1)
    return im

def mkdirs(paths):
    if isinstance(paths, list) and not isinstance(paths, str):
        for path in paths:
            mkdir(path)
    else:
        mkdir(paths)

def mkdir(path):
    if not os.path.exists(path):
        os.makedirs(path)

def save_image(image_numpy, image_path):
    mkdir(os.path.dirname(image_path))
    image_pil = Image.fromarray(image_numpy)
    image_pil.save(image_path)

def save_str_data(data, path):
    mkdir(os.path.dirname(path))
    np.savetxt(path, data, delimiter=",", fmt="%s")

def main():
    a = [1,2,3,4]
    # print(type(a))
    # assert isinstance(a,dict)
if __name__ == '__main__':
    main()